/**
 * @file Coffre.cpp
 * @brief Implémentation de Coffre.
 */

#include "Coffre.h"
#include <cstdlib>
#include <cassert>

Coffre::Coffre(Rarity r) : rarity(r), opened(false) {}

Coffre::~Coffre() {}

// Ouvre le coffre et génère une récompense aléatoire selon la rareté
Reward* Coffre::open()
{
    assert(!opened);
    opened = true;

    int roll    = rand() % 100;
    int berries = 500;
    std::string charName = "";
    int frags   = 0;

    // Personnages possibles par tier (garantis)
    static const char* commonChars[]  = {"Luffy","Zoro","Sanji","Brook","Usopp"};
    static const char* rareChars[]    = {"Zoro","Sanji","Nami","Vivi","Koby"};
    static const char* srChars[]      = {"Ace","Robin","Law","Jinbe","Crocodile"};
    static const char* epicChars[]    = {"Marco","Fujitora","King","Katakuri","Ener"};
    static const char* legChars[]     = {"Shanks","Rayleigh","Akainu","Kizaru","Aokiji"};
    static const char* mythChars[]    = {"BarbeBlanche","Shanks","Kaido","BigMom","Dragon"};

    switch (rarity)
    {
        case Rarity::c:
            charName = commonChars[rand() % 5];
            frags    = 5 + (roll < 30 ? 5 : 0);
            break;
        case Rarity::r:
            charName = rareChars[rand() % 5];
            frags    = 10 + (roll < 30 ? 10 : 0);
            break;
        case Rarity::sr:
            charName = srChars[rand() % 5];
            frags    = 15 + (roll < 25 ? 15 : 0);
            break;
        case Rarity::e:
            charName = epicChars[rand() % 5];
            frags    = 20 + (roll < 20 ? 20 : 0);
            break;
        case Rarity::l:
            charName = legChars[rand() % 5];
            frags    = 25 + (roll < 15 ? 25 : 0);
            break;
        case Rarity::m:
            charName = mythChars[rand() % 6];
            frags    = 40 + (roll < 10 ? 40 : 0);
            break;
    }

    return new Reward(berries, charName, frags, 1.0f);
}

bool   Coffre::isOpened()  const { return opened; }
Rarity Coffre::getRarity() const { return rarity; }

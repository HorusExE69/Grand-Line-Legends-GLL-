/**
 * @file SaveData.cpp
 * @brief Implémentation de SaveData (sauvegarde / chargement).
 */

#include "SaveData.h"
#include "Player.h"
#include "Campaign.h"
#include <fstream>
#include <cassert>

bool SaveData::exists(const std::string& path)
{
    std::ifstream f(path);
    return f.is_open();
}

// Format de sauvegarde :
//   PSEUDO
//   accountLvl xp berries teamMax
//   nbUnlocked
//   charName fragments (x nbUnlocked)
//   arcIdx epIdx

void SaveData::save(const std::string& path, const Player& p, const Campaign& c)
{
    std::ofstream f(path);
    assert(f.is_open());

    f << p.getPseudo()      << "\n";
    f << p.getAccountLvl() << " "
      << p.getXP()         << " "
      << p.getBerries()    << " "
      << p.getTeamMax()    << "\n";

    f << p.getNbUnlock() << "\n";
    for (int i = 0; i < p.getNbUnlock(); i++)
    {
        Character* ch = p.getUnlockCharacter(i);
        f << ch->getName() << " " << p.getFragments(ch->getName()) << "\n";
    }

    f << c.getCurrentArcIdx() << " " << c.getCurrentEpIdx() << "\n";
}

bool SaveData::load(const std::string& path, Player& p, Campaign& c)
{
    std::ifstream f(path);
    if (!f.is_open()) return false;

    std::string pseudo;
    f >> pseudo;
    p.changePseudo(pseudo);

    int accLvl, xp, berries, teamMax;
    f >> accLvl >> xp >> berries >> teamMax;
    p.setAccountLvl(accLvl);
    p.setXP(xp);
    p.setBerries(berries);

    // Ajuster la taille de l'équipe si nécessaire
    int delta = teamMax - p.getTeamMax();
    if (delta > 0) p.addTeamSize(delta);

    int nbUnlocked;
    f >> nbUnlocked;
    for (int i = 0; i < nbUnlocked; i++)
    {
        std::string charName;
        int frags;
        f >> charName >> frags;

        // Chercher le personnage dans la bank et le débloquer
        for (int j = 0; j < p.getNbBank(); j++)
        {
            Character* ch = p.getBankCharacter(j);
            if (ch->getName() == charName)
            {
                p.unlockCharacter(ch);
                p.addFragments(charName, frags);
                break;
            }
        }
    }

    int arcIdx, epIdx;
    f >> arcIdx >> epIdx;
    if (arcIdx >= 0 && arcIdx < NB_ARCS)
        c.selectArc(arcIdx);

    return true;
}

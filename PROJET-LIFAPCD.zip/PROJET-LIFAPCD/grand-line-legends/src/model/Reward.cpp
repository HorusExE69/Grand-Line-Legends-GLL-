/**
 * @file Reward.cpp
 * @brief Implémentation de Reward.
 */

#include "Reward.h"

Reward::Reward(int b, const std::string& charName, int frags, float chance)
{
    berries          = b;
    fragmentCharName = charName;
    nbFragments      = frags;
    dropChance       = chance;
}

int         Reward::getBerries()          const { return berries;          }
std::string Reward::getFragmentCharName() const { return fragmentCharName; }
int         Reward::getNbFragments()      const { return nbFragments;      }
float       Reward::getDropChance()       const { return dropChance;       }

/**
 * @file Game.cpp
 * @brief Implémentation du contrôleur principal Game.
 */

#include "Game.h"
#include "../model/Player.h"
#include "../model/Coffre.h"
#include "../view/ViewText.h"
#include "Battle.h"
#include "Event.h"
#include <fstream>
#include <ctime>
#include <cstdlib>
#include <cassert>
#include <string>

using namespace std;

// ─── Constructeur / Destructeur ─────────────────────────────────────────────

Game::Game(void)
{
    // Initialiser le générateur aléatoire
    srand(static_cast<unsigned int>(time(nullptr)));

    // Charger les personnages depuis le CSV
    ifstream file("./data/Characters.csv");
    player = new Player(file, "./data/capacities/", "Joueur");
    file.close();

    campaign      = new Campaign();
    settings      = new Settings();
    settings->load("./data/settings.txt");
    shop          = new Shop();
    currentBattle = nullptr;

    selectedIndex = 0;
    state         = GameState::MAIN_MENU;
    statusMsg     = "";
}

Game::~Game(void)
{
    delete player;
    delete campaign;
    delete settings;
    delete shop;
    if (currentBattle) delete currentBattle;
}

// ─── Initialisation ──────────────────────────────────────────────────────────

void Game::init(void)
{
    // Le pseudo et le chargement de sauvegarde sont gérés dans la vue
    state = GameState::MAIN_MENU;
}

// ─── Mise à jour ─────────────────────────────────────────────────────────────

void Game::update(Event* ev)
{
    assert(ev != nullptr);

    switch (ev->type)
    {
        case EventType::MAIN_MENU:
            state = GameState::MAIN_MENU;
            selectedIndex = 0;
            break;

        case EventType::SETTINGS:
            state = GameState::SETTINGS;
            selectedIndex = 0;
            break;

        case EventType::PLAY_MENU:
            state = GameState::PLAY_MENU;
            selectedIndex = 0;
            break;

        case EventType::BANK:
            state = GameState::BANK;
            // Ne pas réinitialiser selectedIndex : conserve la position lors du retour depuis BANK_DETAIL
            break;

        case EventType::BANK_DETAIL:
            state = GameState::BANK_DETAIL;
            break;

        case EventType::BANK_UPGRADE:
        {
            Character* c = player->getBankCharacter(selectedIndex);
            if (c && player->isUnlocked(c->getName()))
            {
                int cost  = c->upgradeCost();
                int frags = player->getFragments(c->getName());
                if (frags < UPGRADE_FRAGMENT_COST)
                    statusMsg = "Fragments insuffisants (100 requis pour ameliorer).";
                else if (player->getBerries() < cost)
                    statusMsg = "Berries insuffisants.";
                else
                {
                    player->addBerries(-cost);
                    // Consommer les fragments
                    player->addFragments(c->getName(), -UPGRADE_FRAGMENT_COST);
                    c->updateLvl(1);
                    statusMsg = "Amelioration reussie !";
                }
            }
            state = GameState::BANK_DETAIL;
            break;
        }

        case EventType::BANK_UNLOCK:
        {
            // Débloquer le personnage si 100 fragments disponibles
            Character* c = player->getBankCharacter(selectedIndex);
            if (c && !player->isUnlocked(c->getName()))
            {
                if (!player->unlockCharacter(c))
                    statusMsg = "Fragments insuffisants (100 requis).";
                else
                    statusMsg = "Personnage debloque !";
            }
            state = GameState::BANK_DETAIL;
            break;
        }

        case EventType::CAMPAIGN:
            state = GameState::CAMPAIGN;
            campaign->selectArc(0);
            selectedIndex = 0;
            break;

        case EventType::CAMPAIGN_ARC:
        {
            // Arc 0 toujours accessible ; arc i nécessite arc i-1 complété
            bool accessible = (selectedIndex == 0 ||
                               campaign->getArc(selectedIndex - 1)->completed);
            if (accessible)
            {
                state = GameState::CAMPAIGN_ARC;
                campaign->selectArc(selectedIndex);
                selectedIndex = 0;
            }
            else
            {
                statusMsg = "Arc verrouille : completez l'arc precedent d'abord.";
            }
            break;
        }

        case EventType::CAMPAIGN_EPISODE:
        {
            Arc*  arc  = campaign->getCurrentArc();
            bool  accessible = (selectedIndex == 0 ||
                                arc->episodes[selectedIndex - 1]->completed);
            if (accessible)
            {
                campaign->selectEpisode(selectedIndex);
                state = GameState::BATTLE_PREPA;
                selectedIndex = 0;
            }
            else
            {
                statusMsg = "Episode verrouille : completez l'episode precedent d'abord.";
            }
            break;
        }

        case EventType::PLAY:
            state = GameState::BATTLE_PREPA;
            selectedIndex = 0;
            break;

        case EventType::TEAM:
            state = GameState::TEAM;
            break;

        case EventType::TEAM_CHANGE:
            state = GameState::TEAM_CHANGE;
            selectedIndex = 0;
            break;

        case EventType::BATTLE:
            startBattle();
            state = GameState::BATTLE;
            break;

        case EventType::SHOP:
            // Recharger le shop (offres du jour)
            delete shop;
            shop  = new Shop();
            state = GameState::SHOP;
            selectedIndex = 0;
            break;

        case EventType::SAVE:
            save();
            break;

        case EventType::QUIT:
            save();
            state = GameState::QUIT;
            break;

        case EventType::NONE:
        default:
            break;
    }
}

// ─── Combat ──────────────────────────────────────────────────────────────────

void Game::startBattle()
{
    // Nettoyer le combat précédent
    if (currentBattle) { delete currentBattle; currentBattle = nullptr; }

    // Remettre les personnages joueur à leur PV max avant le combat
    for (int i = 0; i < player->getNbBank(); i++)
    {
        Character* c = player->getBankCharacter(i);
        if (c) c->resetPV();
    }

    currentBattle = new Battle(player);

    // Construire l'équipe ennemie selon la difficulté de l'épisode
    Episode* ep = campaign->getCurrentEpisode();
    buildEnemyTeam(currentBattle->getEnemy(), ep ? ep->difficulty : 3);

    currentBattle->init();
}

static Character* makeNpc(const std::string& npcName, const std::string& type,
                          int pv, int speed, int hakiR, int hakiA, int hakiO)
{
    std::string line = "0," + npcName + "," + type + ",c,"
                     + std::to_string(pv)    + "," + std::to_string(speed) + ","
                     + std::to_string(hakiR) + "," + std::to_string(hakiA) + ","
                     + std::to_string(hakiO);
    return new Character(line, "data/capacities/");
}

static void addNpc(Player* enemy, const std::string& name, const std::string& type,
                   int pv, int speed, int hakiR, int hakiA, int hakiO)
{
    Character* npc = makeNpc(name, type, pv, speed, hakiR, hakiA, hakiO);
    enemy->addToBank(npc);
    enemy->addToTeam(npc);
}

void Game::buildEnemyTeam(Player* enemy, int difficulty)
{
    assert(enemy != nullptr);
    assert(difficulty >= 1);

    Arc*     arc = campaign->getCurrentArc();
    Episode* ep  = campaign->getCurrentEpisode();

    // Déterminer le type d'ennemi selon l'arc
    struct FactionNpc { const char* name; const char* type; };
    FactionNpc faction = {"SoldatMarine", "def"};

    if (arc) {
        const std::string& arcName = arc->name;
        if (arcName == "Orange Town" || arcName == "Village Sirop" || arcName == "Baratie")
            faction = {"PirateSimple", "atk"};
        else if (arcName == "Arlong Park")
            faction = {"PirateSimple", "atk"};
        else if (arcName.find("Whiskey") != std::string::npos ||
                 arcName.find("Alabasta") != std::string::npos ||
                 arcName.find("Little Garden") != std::string::npos)
            faction = {"BaroqueAgent", "int"};
        else if (arcName == "Thriller Bark")
            faction = {"ZombieSimple", "atk"};
        else if (arcName.find("Orange") != std::string::npos)
            faction = {"PirateBaggy", "atk"};
    }

    // Stats de base par difficulté (ennemis normaux volontairement faibles)
    int basePV    = 600 + difficulty * 80;
    int baseSpeed = 50  + difficulty * 3;

    // Agrandir l'équipe ennemie selon le type d'épisode
    if (ep && ep->isBoss) {
        // Boss : 1 boss puissant + 2 gardes
        enemy->addTeamSize(2);

        int bossPV    = 2000 + difficulty * 150;
        int bossSpeed = 60   + difficulty * 2;
        std::string bossName = "BossNPC";
        if (arc) {
            if (arc->name == "Romance Dawn") { bossName = "Morgan"; bossPV = 1200 + difficulty * 100; }
            else if (arc->name == "Orange Town") bossName = "PirateBaggy";
        }
        addNpc(enemy, bossName, "atk", bossPV, bossSpeed, 35, 25, 35);

        // Gardes plus faibles
        addNpc(enemy, faction.name, faction.type, basePV, baseSpeed, 10, 5, 10);
        addNpc(enemy, faction.name, faction.type, basePV, baseSpeed, 10, 5, 10);

    } else if (ep && ep->isMiniBoss) {
        // Mini-boss : 1 mini-boss + 1 sbire
        enemy->addTeamSize(1);

        int mbPV    = 2000 + difficulty * 200;
        int mbSpeed = 65   + difficulty * 2;
        std::string mbName = "MiniBossNPC";
        if (arc && arc->name == "Romance Dawn") mbName = "Helmeppo";

        addNpc(enemy, mbName, "atk", mbPV, mbSpeed, 20, 15, 20);
        addNpc(enemy, faction.name, faction.type, basePV, baseSpeed, 8, 3, 8);

    } else {
        // Combat normal : 3 sbires faibles
        enemy->addTeamSize(2);
        for (int i = 0; i < 3; i++)
            addNpc(enemy, faction.name, faction.type, basePV, baseSpeed, 8, 3, 8);
    }
}

void Game::applyRewards()
{
    Episode* ep = campaign->getCurrentEpisode();
    if (!ep) return;

    // Berries de base pour chaque combat (proportionnel à la difficulté)
    int baseReward = ep->difficulty * 150;
    if (ep->isMiniBoss) baseReward = ep->difficulty * 300;
    if (ep->isBoss)     baseReward = ep->difficulty * 500;
    player->addBerries(baseReward);

    for (int i = 0; i < ep->nbRewards; i++)
    {
        Reward* r = ep->rewards[i];
        if (!r) continue;

        // Test de probabilité
        int roll = rand() % 100;
        if (roll < static_cast<int>(r->getDropChance() * 100))
        {
            player->addBerries(r->getBerries());
            if (!r->getFragmentCharName().empty())
                player->addFragments(r->getFragmentCharName(), r->getNbFragments());
        }
    }

    // XP selon la difficulté
    player->addXP(ep->difficulty * 100);
    campaign->completeCurrentEpisode();
}

// ─── Navigation dans les listes ──────────────────────────────────────────────

void Game::moveSelectionUp()
{
    if (selectedIndex > 0) selectedIndex--;
}

void Game::moveSelectionDown()
{
    // Borne supérieure selon l'état
    int max = 0;
    switch (state)
    {
        case GameState::BANK:
            max = player->getNbBank() - 1; break;
        case GameState::CAMPAIGN:
            max = campaign->getNbArcs() - 1; break;
        case GameState::CAMPAIGN_ARC:
            max = campaign->getCurrentArc()->nbEpisodes - 1; break;
        case GameState::TEAM_CHANGE:
            max = player->getNbUnlock() - 1; break;
        default:
            max = 9; break;
    }
    if (selectedIndex < max) selectedIndex++;
}

void Game::confirmSelection()
{
    switch (state)
    {
        case GameState::TEAM_CHANGE:
        {
            Character* c = player->getUnlockCharacter(selectedIndex);
            if (c) player->addToTeam(c);
            break;
        }
        default:
            break;
    }
}

// ─── Entrées clavier ─────────────────────────────────────────────────────────

EventType Game::input(char c)
{
    switch (state)
    {
        case GameState::MAIN_MENU:    return inputMainMenu(c);
        case GameState::SETTINGS:     return inputSettings(c);
        case GameState::PLAY_MENU:    return inputPlayMenu(c);
        case GameState::BANK:         return inputBank(c);
        case GameState::BANK_DETAIL:  return inputBankDetail(c);
        case GameState::CAMPAIGN:     return inputCampaign(c);
        case GameState::CAMPAIGN_ARC: return inputCampaignArc(c);
        case GameState::BATTLE_PREPA: return inputBattlePrepa(c);
        case GameState::BATTLE:       return inputBattle(c);
        case GameState::TEAM:         return inputTeam(c);
        case GameState::TEAM_CHANGE:  return inputTeamChange(c);
        case GameState::SHOP:         return inputShop(c);
        default:                      return EventType::NONE;
    }
}

EventType Game::inputMainMenu(char c)
{
    switch (c)
    {
        case 'j': return EventType::PLAY_MENU;
        case 'p': return EventType::SETTINGS;
        case 'q': return EventType::QUIT;
        default:  return EventType::NONE;
    }
}

EventType Game::inputSettings(char c)
{
    switch (c)
    {
        case 'f': settings->toggleFps();
                  { char b[32]; snprintf(b, sizeof(b), "FPS : %d", settings->getFps()); statusMsg = b; }
                  return EventType::NONE;
        case '+': settings->volumeUp();
                  { char b[32]; snprintf(b, sizeof(b), "Volume : %d%%", settings->getVolume()); statusMsg = b; }
                  return EventType::NONE;
        case '-': settings->volumeDown();
                  { char b[32]; snprintf(b, sizeof(b), "Volume : %d%%", settings->getVolume()); statusMsg = b; }
                  return EventType::NONE;
        case 'l': settings->brightnessUp();
                  { char b[32]; snprintf(b, sizeof(b), "Luminosite : %d%%", settings->getBrightness()); statusMsg = b; }
                  return EventType::NONE;
        case 'k': settings->brightnessDown();
                  { char b[32]; snprintf(b, sizeof(b), "Luminosite : %d%%", settings->getBrightness()); statusMsg = b; }
                  return EventType::NONE;
        case 's': settings->save("./data/settings.txt"); statusMsg = "Parametres sauvegardes."; return EventType::NONE;
        case 'm': return EventType::MAIN_MENU;
        default:  return EventType::NONE;
    }
}

EventType Game::inputPlayMenu(char c)
{
    switch (c)
    {
        case 'b': return EventType::BANK;
        case 'c': return EventType::CAMPAIGN;
        case 's': return EventType::SHOP;
        case 'm': return EventType::MAIN_MENU;
        default:  return EventType::NONE;
    }
}

EventType Game::inputBank(char c)
{
    switch (c)
    {
        case 65: moveSelectionUp();   return EventType::NONE; // flèche haut
        case 66: moveSelectionDown(); return EventType::NONE; // flèche bas
        case 10:
        case 13: return EventType::BANK_DETAIL; // entrée
        case 'm': return EventType::PLAY_MENU;
        default:  return EventType::NONE;
    }
}

EventType Game::inputBankDetail(char c)
{
    switch (c)
    {
        case 'u': return EventType::BANK_UPGRADE;
        case 'd': return EventType::BANK_UNLOCK;
        case 'r': return EventType::BANK;
        default:  return EventType::NONE;
    }
}

EventType Game::inputCampaign(char c)
{
    switch (c)
    {
        case 65: campaign->arcUp();   selectedIndex = campaign->getCurrentArcIdx(); return EventType::NONE;
        case 66: campaign->arcDown(); selectedIndex = campaign->getCurrentArcIdx(); return EventType::NONE;
        case 10:
        case 13: return EventType::CAMPAIGN_ARC;
        case 'm': return EventType::PLAY_MENU;
        default:  return EventType::NONE;
    }
}

EventType Game::inputCampaignArc(char c)
{
    switch (c)
    {
        case 65: campaign->episodeUp();   selectedIndex = campaign->getCurrentEpIdx(); return EventType::NONE;
        case 66: campaign->episodeDown(); selectedIndex = campaign->getCurrentEpIdx(); return EventType::NONE;
        case 10:
        case 13: return EventType::CAMPAIGN_EPISODE;
        case 'r': return EventType::CAMPAIGN;
        default:  return EventType::NONE;
    }
}

EventType Game::inputBattlePrepa(char c)
{
    switch (c)
    {
        case 'c': return EventType::BATTLE;
        case 'e': return EventType::TEAM_CHANGE;
        case 'r': return EventType::CAMPAIGN_ARC;
        case 'm': return EventType::PLAY_MENU;
        default:  return EventType::NONE;
    }
}

EventType Game::inputBattle(char c)
{
    switch (c)
    {
        case 'r': return EventType::CAMPAIGN_ARC;
        case 'm': return EventType::PLAY_MENU;
        default:  return EventType::NONE;
    }
}

EventType Game::inputTeam(char c)
{
    switch (c)
    {
        case 'g': return EventType::TEAM_CHANGE;
        case 'r': return EventType::PLAY;
        default:  return EventType::NONE;
    }
}

EventType Game::inputTeamChange(char c)
{
    switch (c)
    {
        case 65:  moveSelectionUp();   return EventType::NONE;
        case 66:  moveSelectionDown(); return EventType::NONE;
        case 68:  confirmSelection();  return EventType::NONE; // flèche gauche
        case 'r': return EventType::PLAY; // retour direct à BATTLE_PREPA
        default:  return EventType::NONE;
    }
}

EventType Game::inputShop(char c)
{
    // Acheter un coffre (offres permanentes [1],[2],[3])
    if (c >= '1' && c <= '3')
    {
        int pi = c - '1';
        const ShopOffer& offer = shop->getPermanent(pi);

        if (player->getBerries() < offer.costBerries)
        {
            statusMsg = "Berries insuffisants.";
        }
        else if (offer.isCoffre)
        {
            player->addBerries(-offer.costBerries);
            Coffre coffre(offer.coffreRar);
            Reward* r = coffre.open();
            if (r)
            {
                player->addFragments(r->getFragmentCharName(), r->getNbFragments());
                statusMsg = "Coffre : +" + std::to_string(r->getNbFragments())
                            + " fragments de " + r->getFragmentCharName() + " !";
                delete r;
            }
        }
        return EventType::NONE;
    }
    switch (c)
    {
        case 'm': return EventType::PLAY_MENU;
        default:  return EventType::NONE;
    }
}

// ─── Sauvegarde ──────────────────────────────────────────────────────────────

void Game::save()
{
    SaveData::save(SAVE_PATH, *player, *campaign);
    settings->save("./data/settings.txt");
}

bool Game::load()
{
    return SaveData::load(SAVE_PATH, *player, *campaign);
}

// ─── Accesseurs ──────────────────────────────────────────────────────────────

Player*     Game::getPlayer()        const { return player;        }
Campaign*   Game::getCampaign()      const { return campaign;      }
Settings*   Game::getSettings()      const { return settings;      }
Shop*       Game::getShop()          const { return shop;          }
Battle*     Game::getCurrentBattle() const { return currentBattle; }
GameState   Game::getState()         const { return state;         }
int         Game::getSelectedIndex() const { return selectedIndex; }
std::string Game::getStatusMsg()     const { return statusMsg;     }
void        Game::clearStatusMsg()         { statusMsg = "";        }
void        Game::setSelectedIndex(int i)  { selectedIndex = i;     }

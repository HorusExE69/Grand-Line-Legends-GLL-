/**
 * @file Battle.cpp
 * @brief Implémentation de Battle.
 */

#include "Battle.h"
#include <cassert>
#include <cstdlib>

using namespace std;

Battle::Battle(Player* p)
{
    player  = p;
    enemy   = new Player("Ennemi");
    turn    = 0;
    nbLog   = 0;
    map     = new BattleMap;
}

Battle::~Battle()
{
    delete enemy;
    delete map;
}

// Initialise la grille en plaçant les équipes
void Battle::init()
{
    assert(player != nullptr);
    map->init(player, enemy);
}

// ─── Déroulement du combat ───────────────────────────────────────────────────

void Battle::playAllTurns()
{
    while (!isOver())
    {
        playTurn();
        turn++;
    }
}

bool Battle::playNextTurn()
{
    if (isOver()) return false;
    playTurn();
    turn++;
    return true;
}

void Battle::playTurn()
{
    clearLog();

    // Appliquer les effets passifs avant les attaques
    for (int i = 0; i < player->getTeamSize(); i++)
    {
        Character* c = player->getTeamCharacter(i);
        if (c && c->getPV() > 0) c->applyPassives();
    }
    for (int i = 0; i < enemy->getTeamSize(); i++)
    {
        Character* c = enemy->getTeamCharacter(i);
        if (c && c->getPV() > 0) c->applyPassives();
    }

    int      orderSize = 0;
    Square** order     = getOrder(orderSize);

    for (int i = 0; i < orderSize; i++)
    {
        bool side = (order[i]->x == 0); // true = joueur, false = ennemi
        playCharacter(order[i], side);
    }

    delete[] order;
}

void Battle::playCharacter(Square* sq, bool playerSide)
{
    if (!sq || !sq->inmate || sq->inmate->getPV() <= 0) return;
    if (sq->inmate->stunned) { sq->inmate->stunned = false; return; }

    Capacity* capa = sq->inmate->chooseCapa();
    if (!capa) return;

    capa->launcher = sq;

    // Sélectionner une cible aléatoire dans l'équipe adverse
    Player* targets = playerSide ? enemy : player;
    int     size    = targets->getTeamSize();
    if (size == 0) return;

    // Cibler un personnage vivant
    int tries = 0;
    int idx   = rand() % size;
    while (targets->getTeamCharacter(idx)->getPV() <= 0 && tries < size)
    {
        idx = (idx + 1) % size;
        tries++;
    }
    if (targets->getTeamCharacter(idx)->getPV() <= 0) return;

    int targetSide = playerSide ? 1 : 0;
    capa->addTarget(&map->getSquare(targetSide, idx));
    capa->use();

    // Ajouter au log
    addLog(sq->inmate->getName(),
           capa->getName(),
           targets->getTeamCharacter(idx)->getName(),
           capa->getDamage());
}

// ─── État du combat ──────────────────────────────────────────────────────────

bool Battle::isDead(Player* p) const
{
    assert(p != nullptr);
    for (int i = 0; i < p->getTeamSize(); i++)
    {
        if (p->getTeamCharacter(i)->getPV() > 0) return false;
    }
    return true;
}

bool Battle::isOver() const
{
    return isDead(player) || isDead(enemy);
}

Player* Battle::getWinner() const
{
    if (isDead(player) && isDead(enemy)) return nullptr;
    if (isDead(player))                  return enemy;
    if (isDead(enemy))                   return player;
    return nullptr;
}

// ─── Ordre d'attaque (tri bulle par vitesse croissante) ──────────────────────

Square** Battle::getOrder(int& outSize) const
{
    int maxN = player->getTeamSize() + enemy->getTeamSize();
    Square** order = new Square*[maxN];
    int      k     = 0;

    for (int i = 0; i < player->getTeamSize(); i++)
    {
        if (player->getTeamCharacter(i)->getPV() > 0)
            order[k++] = &map->getSquare(0, i);
    }
    for (int j = 0; j < enemy->getTeamSize(); j++)
    {
        if (enemy->getTeamCharacter(j)->getPV() > 0)
            order[k++] = &map->getSquare(1, j);
    }

    // Tri bulle par vitesse décroissante (le plus rapide joue en premier)
    for (int i = 0; i < k - 1; i++)
    {
        for (int j = 0; j < k - i - 1; j++)
        {
            if (order[j] && order[j + 1] &&
                order[j]->inmate && order[j + 1]->inmate &&
                order[j]->inmate->speed < order[j + 1]->inmate->speed)
            {
                Square* tmp  = order[j];
                order[j]     = order[j + 1];
                order[j + 1] = tmp;
            }
        }
    }

    outSize = k;
    return order;
}

// ─── Log ────────────────────────────────────────────────────────────────────

void Battle::addLog(const string& atk, const string& cap,
                    const string& tgt, int val)
{
    if (nbLog >= MAX_LOG) return;
    log[nbLog].attacker = atk;
    log[nbLog].capa     = cap;
    log[nbLog].target   = tgt;
    log[nbLog].value    = val;
    nbLog++;
}

void             Battle::clearLog()          { nbLog = 0; }
int              Battle::getNbLog()    const { return nbLog; }
const BattleLog& Battle::getLog(int i) const
{
    assert(i >= 0 && i < nbLog);
    return log[i];
}

// ─── Accesseurs ─────────────────────────────────────────────────────────────

Player* Battle::getPlayer() const { return player; }
Player* Battle::getEnemy()  const { return enemy;  }
int     Battle::getTurn()   const { return turn;   }

/**
 * @file testCampaign.cpp
 * @brief Tests de régression pour la classe Campaign.
 *
 * Compile avec : make test_campaign
 * Exécute avec : ./bin/testCampaign
 */

#include "../src/model/Campaign.h"
#include <cassert>
#include <cstdio>

// ─── Tests ───────────────────────────────────────────────────────────────────

static void testNbArcs()
{
    Campaign c;
    assert(c.getNbArcs() == NB_ARCS);
    assert(c.getNbArcs() == 17);
    printf("[OK] Campaign : nombre d'arcs = %d\n", NB_ARCS);
}

static void testArcNames()
{
    Campaign c;
    // Vérifier quelques arcs clés
    assert(c.getArc(0)->name == "Romance Dawn");
    assert(c.getArc(9)->name == "Alabasta");
    assert(c.getArc(16)->name == "Marine Ford");
    printf("[OK] Campaign : noms des arcs\n");
}

static void testArcBoss()
{
    Campaign c;
    assert(c.getArc(0)->bossName  == "Morgan");
    assert(c.getArc(9)->bossName  == "Crocodile");
    assert(c.getArc(15)->bossName == "Magellan");
    printf("[OK] Campaign : noms des boss\n");
}

static void testArcEpisodes()
{
    Campaign c;
    // Chaque arc doit avoir au moins un épisode boss
    for (int i = 0; i < NB_ARCS; i++)
    {
        Arc* arc = c.getArc(i);
        assert(arc->nbEpisodes > 0);
        // Le dernier épisode doit être un boss
        assert(arc->episodes[arc->nbEpisodes - 1]->isBoss);
    }
    printf("[OK] Campaign : structure des episodes\n");
}

static void testNavigation()
{
    Campaign c;
    assert(c.getCurrentArcIdx() == 0);

    c.arcDown();
    assert(c.getCurrentArcIdx() == 1);

    c.arcUp();
    assert(c.getCurrentArcIdx() == 0);

    // Limites
    c.arcUp(); // ne doit pas passer en dessous de 0
    assert(c.getCurrentArcIdx() == 0);

    c.selectArc(16);
    c.arcDown(); // ne doit pas dépasser NB_ARCS-1
    assert(c.getCurrentArcIdx() == 16);

    printf("[OK] Campaign : navigation arcs\n");
}

static void testEpisodeNavigation()
{
    Campaign c;
    c.selectArc(0);
    assert(c.getCurrentEpIdx() == 0);

    c.episodeDown();
    assert(c.getCurrentEpIdx() == 1);

    c.episodeUp();
    assert(c.getCurrentEpIdx() == 0);

    printf("[OK] Campaign : navigation episodes\n");
}

static void testBanned()
{
    Campaign c;
    // Arc 8 (Drum Island) : Nami est bannie
    Arc* drumIsland = c.getArc(8);
    assert(drumIsland->isBanned("Nami"));
    assert(!drumIsland->isBanned("Luffy"));
    printf("[OK] Campaign : personnages bannis\n");
}

static void testUnlockChance()
{
    Campaign c;
    // Arc 0 : Zoro 100%
    assert(c.getArc(0)->unlockChance == 1.0f);
    // Arc 1 : Nami 50%
    assert(c.getArc(1)->unlockChance == 0.5f);
    printf("[OK] Campaign : chances de deblocage\n");
}

static void testCompletion()
{
    Campaign c;
    c.selectArc(0);
    c.selectEpisode(0);
    assert(!c.getCurrentEpisode()->completed);

    c.completeCurrentEpisode();
    assert(c.getCurrentEpisode()->completed);
    printf("[OK] Campaign : completion episode\n");
}

// ─── Main ────────────────────────────────────────────────────────────────────

int main()
{
    printf("=== Tests Campaign ===\n");
    testNbArcs();
    testArcNames();
    testArcBoss();
    testArcEpisodes();
    testNavigation();
    testEpisodeNavigation();
    testBanned();
    testUnlockChance();
    testCompletion();
    printf("=== Tous les tests Campaign passes ===\n");
    return 0;
}

================================================================================
  GRAND LINE LEGENDS
  Jeu RPG tour par tour -- theme One Piece
  inspire de Souls et Raid Shadow Legends
================================================================================

  Cours    : LIFAPCD -- Universite Claude Bernard Lyon 1
  Projet   : Grand Line Legends
  GitLab   : https://forge.univ-lyon1.fr/p2405025/grand-line-legends

================================================================================
  COMPILATION
================================================================================

  Prerequis
  ---------
  Outil       Linux                              macOS
  --------    -----                              -----
  g++         sudo apt install g++               Xcode Command Line Tools
  SDL2        sudo apt install libsdl2-dev        brew install sdl2
  SDL2_ttf    sudo apt install libsdl2-ttf-dev    brew install sdl2_ttf

  Commandes make
  --------------
  make              Version graphique SDL2    --> bin/GLL
  make text         Version textuelle         --> bin/GLL_text
  make tests        Tests de regression       --> bin/test*
  make docu         Documentation Doxygen     --> doc/html/index.html
  make clean        Supprime obj/ bin/ doc/html/

  Execution
  ---------
  ./bin/GLL              Version graphique
  ./bin/GLL_text         Version textuelle

  Tests individuels :
  ./bin/testCharacter
  ./bin/testPlayer
  ./bin/testBattle
  ./bin/testCampaign

================================================================================
  ORGANISATION DES FICHIERS
================================================================================

  grand-line-legends/
  |-- Makefile                  Compile les deux versions + tests + doc
  |-- README.txt                Ce fichier
  |-- Cahier_des_charges        Cahier des charges initial
  |-- CLAUDE.md                 Notes d'architecture
  |-- doc/
  |   |-- doxyfile              Configuration Doxygen
  |   |-- compte_rendu.pdf      Compte rendu complet du projet
  |   `-- uml/
  |       |-- classes.drawio    Diagramme de classes (diagrams.net)
  |       |-- model.html        Diagramme classes modele (navigateur -> PDF)
  |       |-- mvc.html          Architecture MVC (navigateur -> PDF)
  |       |-- battle_sequence.html  Sequence combat (navigateur -> PDF)
  |       `-- gantt.html        Planning Gantt (navigateur -> PDF)
  |-- src/
  |   |-- model/                Modele : donnees du jeu (16 modules)
  |   |   |-- Utils.h/.cpp          Enumerations partagees (GameState, EventType...)
  |   |   |-- Characters.h/.cpp     Personnage (stats, capacites, niveaux)
  |   |   |-- Capacity.h/.cpp       Capacite (attaque/soin/effet)
  |   |   |-- Effects.h/.cpp        Effet applique par une capacite
  |   |   |-- Squares.h/.cpp        Case de la grille de combat
  |   |   |-- BattleMap.h/.cpp      Grille 2x10
  |   |   |-- Player.h/.cpp         Joueur (bank, equipe, XP, berries, fragments)
  |   |   |-- Reward.h/.cpp         Recompense (berries, fragments, probabilite)
  |   |   |-- Episode.h/.cpp        Episode d'un arc
  |   |   |-- Arc.h/.cpp            Arc narratif (boss, recompenses, bannis)
  |   |   |-- Campaign.h/.cpp       17 arcs + navigation
  |   |   |-- Family.h/.cpp         Familles One Piece (bonus d'equipe)
  |   |   |-- Settings.h/.cpp       Parametres (fps, volume, luminosite)
  |   |   |-- Coffre.h/.cpp         Coffre (loot box aleatoire)
  |   |   |-- Shop.h/.cpp           Boutique (offres jour/semaine/mois)
  |   |   `-- SaveData.h/.cpp       Sauvegarde/chargement (data/save.txt)
  |   |-- controller/           Controleurs : logique de jeu
  |   |   |-- main.cpp              Point d'entree SDL2
  |   |   |-- mainText.cpp          Point d'entree terminal
  |   |   |-- Game.h/.cpp           Controleur central (etats, entrees, dispatch)
  |   |   |-- Battle.h/.cpp         Combat tour par tour
  |   |   `-- Event.h               Evenements inter-modules (EventType)
  |   `-- view/                 Vues : affichage uniquement
  |       |-- winTxt.h/.cpp         Librairie fenetre texte (fournie, NE PAS MODIFIER)
  |       |-- ViewText.h/.cpp       Vue textuelle (WinTXT exclusivement, sans SDL)
  |       `-- ViewGraph.h/.cpp      Vue graphique SDL2
  |-- data/
  |   |-- Characters.csv        67 personnages (id, nom, type, rarete, stats)
  |   |-- capacities/           Un CSV par personnage (attaques et effets)
  |   |-- save.txt              Sauvegarde (genere a l'execution)
  |   `-- settings.txt          Parametres (genere a l'execution)
  `-- tests/
      |-- testCharacter.cpp     6 tests Character (assert)
      |-- testPlayer.cpp        9 tests Player
      |-- testBattle.cpp        5 tests Battle
      `-- testCampaign.cpp      9 tests Campaign (17 arcs)

================================================================================
  DIAGRAMME DE CLASSES (doc/uml/classes.drawio)
================================================================================

  Ouverture et navigation
  -----------------------
  Fichier : doc/uml/classes.drawio
  Outil   : diagrams.net (gratuit, en ligne ou application de bureau)
    - En ligne   : https://app.diagrams.net  ->  File -> Open from -> Device
    - Bureau     : https://github.com/jgraph/drawio-desktop/releases
    - VS Code    : extension "Draw.io Integration" (hediet.vscode-drawio)

  Une fois ouvert :
    - Ctrl+Maj+H       recentre le diagramme
    - Ctrl+Maj+F       zoom pour tout afficher
    - Molette souris   zoom avant / arriere
    - Clic milieu ou espace+glisser  deplace la vue
    - Clic sur un bloc puis F2  pour editer le contenu

  Export PDF depuis diagrams.net :
    File -> Export as -> PDF  (cocher "Fit page")

  Organisation des blocs
  ----------------------
  Le diagramme est divise en trois zones (indiquees par les bannieres colorees) :

    [ model ]      Blocs bleus   -- donnees pures, aucun affichage
    [ controller ] Blocs verts   -- logique de jeu (Game, Battle)
    [ view ]       Blocs orange  -- affichage uniquement (ViewText, ViewGraph)

  Les blocs model sont disposes sur 3 rangees (haut vers bas) :
    Rangee 0 : Effect, Capacity, Character, Player, Campaign
    Rangee 1 : Squares, BattleMap, Reward, Episode, Arc
    Rangee 2 : Coffre, Shop, Family, Settings, SaveData

  Signification des fleches
  -------------------------
  Chaque fleche porte une etiquette indiquant le nom ou la multiplicite
  de la relation.  Quatre types sont utilises (legende en bas du diagramme) :

  Fleche             Forme                     Signification
  ------             -----                     -------------
  Composition        Losange plein + fleche     L'objet source possede et detruit
                                                l'objet cible (ex. Character possede
                                                ses Capacity*)
  Agregation         Losange vide + fleche      L'objet source reference l'objet
                                                cible sans en etre proprietaire
                                                (ex. Capacity reference un Effect*)
  Association        Fleche pleine              Lien de navigation simple
                                                (ex. Game -> Player, Game -> Campaign)
  Dependance         Fleche en pointilles       Utilisation temporaire ou creation
                                                (ex. ViewText cree un Event,
                                                 SaveData serialise Player)

  Couleur des fleches :
    Noir  (#1a1a1a)  -- relations internes au package model
    Vert  (#2d6a2d)  -- relations depuis le controller vers model ou view
    Orange(#b35900)  -- relations depuis la view vers controller

  Regles de conception reflectees dans le diagramme
  --------------------------------------------------
  - La vue NE MODIFIE JAMAIS le modele directement :
      ViewText / ViewGraph  -->  emettent Event  -->  Game::update() traite
  - Game est le seul proprietaire de Player, Campaign, Settings, Shop, Battle
  - Battle cree son propre Player* enemy et le supprime dans ~Battle
  - SaveData est une classe statique (methodes save/load, pas d'attributs)

================================================================================
  FONCTIONNALITES
================================================================================

  Menu principal
  --------------
  [J]  Jouer        --> Menu de jeu
  [P]  Parametres   --> fps (30/60), volume, luminosite
  [Q]  Quitter      --> sauvegarde automatique

  Bank
  ----
  - Liste des 67 personnages avec type, rarete, PV, niveau, statut debloque
  - Vue detaillee : stats completes, Haki, capacites avec types et chances
  - Deblocage : 100 fragments du personnage requis
  - Amelioration : cout en berries (croit avec le niveau et la rarete)
  - Statut des fragments affiche en temps reel

  Campagne (17 arcs)
  ------------------
  Arc               Boss                    Deblocage
  ---               ----                    ---------
  Romance Dawn      Morgan                  Zoro 100%
  Orange Town       Baggy                   Nami 50%
  Village Sirop     Kuro                    Usopp 100%
  Baratie           Don Krieg               Sanji 100%
  Arlong Park       Arlong                  Nami 50%
  Logue Town        Smoker                  Baggy 100%
  Whiskey Peak      Mr.5 & Miss Valentine   Vivi 100%
  Little Garden     Mr.3 & Miss GW          Brogy 50%
  Drum Island       Wapol                   Chopper 100% (Nami bannie)
  Alabasta          Crocodile               Robin 100%
  Skypea            Ener                    --
  Water Seven       Franky                  Franky 50%
  Enies Lobby       Rob Lucci               Franky 50%
  Thriller Bark     Gecko Moria             Brook 100%
  Amazon Lily       Boa Hancock             Boa Hancock 100%
  Impel Down        Magellan                Bon Clay + multi 25%
  Marine Ford       Garp/Sengoku/Akainu     Ace 50% + multi

  Structure de chaque arc : sbires --> mini-boss --> boss final
  Recompenses : berries + fragments de personnage (avec probabilites de drop)

  Combat
  ------
  - Grille 2x10 (joueur ligne 0, ennemi ligne 1)
  - Ordre d'attaque par vitesse decroissante
  - Capacites choisies aleatoirement selon leurs pourcentages
  - Effets disponibles : Damage, Heal, Stun, Bleeding, Resist, Push, Pull, Swap
  - Log des actions affiche a chaque tour

  Familles de personnages (bonus d'equipe)
  -----------------------------------------
  Famille             Membres                         Bonus
  -------             -------                         -----
  Monkey D.           Garp, Luffy, Dragon             +25% PV
  Trio de Freres      Sabo, Ace, Luffy                +25% Attaque
  Revolutionnaires    Sabo, Dragon, Ivankov           +15% Defense
  Empereurs           BarbeBlanche, BarbeNoire...     +20% PV
  Amiraux             Akainu, Aokiji, Kizaru...       +20% Defense
  Mugiwara            Les 9 Chapeaux de Paille        +20% Attaque
  Marines             Garp, Sengoku, Smoker, Koby     +15% Defense
  Equipage BB         BarbeBlanche, Ace, Marco, Izo   +20% PV

  Shop
  ----
  - Offre journaliere  : change chaque jour
  - Offre hebdomadaire : change chaque semaine
  - Offre mensuelle    : change chaque mois
  - 3 offres permanentes : Coffre Commun, Coffre Rare, Coffre Epique

  Systeme de progression
  ----------------------
  - Berries    : monnaie gagnee en combat et au shop
  - XP         : gagnee en completant des episodes --> niveau de compte 1 a 10
  - Slots      : 1 au depart, +1 par niveau de compte (max 10)
  - Fragments  : 100 fragments par personnage pour le debloquer

  Sauvegarde
  ----------
  Au lancement : choix nouvelle partie ou charger une sauvegarde.
  Sauvegarde automatique a la fermeture.
  Fichier : data/save.txt (format texte lisible)

================================================================================
  FORMAT DES DONNEES
================================================================================

  data/Characters.csv
  -------------------
  Format : id,name,type,rarity,pv,speed,hakiR,hakiA,hakiO
  Exemple : 1,Luffy,atk,c,4000,105,80,90,90

  type   : atk / def / sup / int / snp / mag
  rarity : c (commun) / r (rare) / sr / e (epique) / l (legendaire) / m (mythique)

  data/capacities/<Nom>.csv
  -------------------------
  Format : id,character,name,type1,type2,damage,heal,targetType,
           targetCount,gearLevel,unlockLvl,effect,percentage
  Exemple : 1,Ace,Fire Fist,fire,punch,2300,0,Enemy,1,3,15,Damage,40

  targetType : Self / Ally / Enemy / AllAllies / AllEnemies / All
  effect     : Damage / Heal / Buff / Debuff / Resist / Stun / Swap / Bleeding
               Push / Pull
  percentage : probabilite d'utilisation (100 = capacite passive)

================================================================================
  ARCHITECTURE MVC
================================================================================

  main.cpp / mainText.cpp
          |
          v
      Game (controleur central -- etats, entrees, dispatch)
     +-------+------------+-------------+----------+
     |       |            |             |          |
  Player  Campaign     Settings       Shop     Battle
     |       |                                    |
  Bank    Arcs --> Episodes --> Rewards      BattleMap
     |
  Characters --> Capacities --> Effects

  La vue (ViewText / ViewGraph) ne modifie JAMAIS le modele directement.
  Elle emet des Event que Game::update() traite, puis relit l'etat en lecture seule.

================================================================================
  REGLES DE PROGRAMMATION RESPECTEES
================================================================================

  - Pas de variable globale
  - Passage par const Type& en entree, Type& en entree/sortie
  - const sur tous les accesseurs
  - assert() pour valider les preconditions
  - Gestion memoire : chaque new a son delete correspondant
  - Doxygen : tous les headers documentes (/** @brief ... */)
  - Modularite : une classe = un module .h/.cpp
  - Aucun cout/cin dans ViewText : WinTXT utilise exclusivement

================================================================================

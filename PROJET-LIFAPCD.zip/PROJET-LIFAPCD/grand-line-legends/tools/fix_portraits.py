"""
fix_portraits.py — Recharge et recadre intelligemment les portraits problématiques.
Recadrage portrait : on prend les 60% supérieurs du personnage (tête + torse).
Usage : python tools/fix_portraits.py
"""
import os, sys, time, requests
from io import BytesIO
from PIL import Image
from rembg import remove, new_session

HEADERS  = {"User-Agent": "Mozilla/5.0"}
API_BASE = "https://onepiece.fandom.com/api.php"
OUT_DIR  = "assets"
SIZE     = (128, 128)

# Personnages à re-traiter (11 problèmes + 4 fonds pleins + Urouge)
# Format : game_name -> wiki_article
FIX = {
    # Problèmes de centrage / contenu manquant
    "Burgess":    "Jesus Burgess",
    "Carrot":     "Carrot",
    "Crocodile":  "Crocodile",
    "DoggyBroggy":"Dorry",
    "Ener":       "Enel",
    "Izo":        "Izou",
    "Kizaru":     "Borsalino",
    "Robin":      "Nico Robin",
    "Sanji":      "Vinsmoke Sanji",
    "Vegapunk":   "Vegapunk",
    "Yamato":     "Yamato",
    # Fonds pas supprimés (100% fill)
    "Fujitora":   "Fujitora",
    "Momonosuke": "Kozuki Momonosuke",
    "Ryokugyu":   "Ryokugyu",
    # Renommage Berouge → Urouge
    "Urouge":     "Urouge",
}

# Chargement modèle anime
print("Chargement modele isnet-anime...")
session = new_session("isnet-anime")
print("Pret.\n")


def get_url(wiki_title: str) -> str | None:
    r = requests.get(API_BASE, params={
        "action": "query", "titles": wiki_title,
        "prop": "pageimages", "piprop": "name",
        "format": "json", "pilimit": 1,
    }, headers=HEADERS, timeout=15)
    if r.status_code != 200:
        return None
    pages = r.json().get("query", {}).get("pages", {})
    fn = None
    for p in pages.values():
        fn = p.get("pageimage")
        break
    if not fn:
        return None
    r2 = requests.get(API_BASE, params={
        "action": "query", "titles": f"File:{fn}",
        "prop": "imageinfo", "iiprop": "url", "format": "json",
    }, headers=HEADERS, timeout=15)
    for p in r2.json().get("query", {}).get("pages", {}).values():
        info = p.get("imageinfo", [])
        if info:
            return info[0].get("url")
    return None


def smart_crop(img: Image.Image) -> Image.Image:
    """
    Recadrage intelligent pour portrait :
    - Prend les 58% supérieurs du personnage (tête + torse)
    - Centre horizontalement sur la largeur du personnage
    - Remplit 128×128 avec fond transparent
    """
    bbox = img.getbbox()
    if not bbox:
        return img.resize(SIZE, Image.LANCZOS)

    x0, y0, x1, y1 = bbox
    h = y1 - y0
    w = x1 - x0

    # Ne garder que le haut du personnage (58%)
    crop_h = int(h * 0.58)
    crop_box = (x0, y0, x1, y0 + crop_h)
    cropped = img.crop(crop_box)

    # Réduire pour tenir dans SIZE en gardant le ratio
    cropped.thumbnail(SIZE, Image.LANCZOS)

    # Centrer dans 128x128
    canvas = Image.new("RGBA", SIZE, (0, 0, 0, 0))
    ox = (SIZE[0] - cropped.width)  // 2
    oy = (SIZE[1] - cropped.height) // 2
    canvas.paste(cropped, (ox, oy), cropped)
    return canvas


def process(game_name: str, wiki_title: str) -> bool:
    print(f"[{game_name}] <- {wiki_title}")

    url = get_url(wiki_title)
    if not url:
        print(f"  URL introuvable")
        return False

    r = requests.get(url, headers=HEADERS, timeout=25)
    if r.status_code != 200:
        print(f"  HTTP {r.status_code}")
        return False

    img = Image.open(BytesIO(r.content)).convert("RGBA")
    print(f"  Taille source : {img.size}")

    # Supprimer le fond avec isnet-anime
    buf = BytesIO()
    img.save(buf, "PNG")
    result = Image.open(BytesIO(remove(buf.getvalue(), session=session))).convert("RGBA")

    # Recadrage portrait intelligent
    portrait = smart_crop(result)

    # Vérif
    vis = sum(1 for px in portrait.getchannel("A").getdata() if px > 30)
    pct = vis * 100 // (SIZE[0] * SIZE[1])
    print(f"  Visible : {pct}%")

    out = os.path.join(OUT_DIR, f"char_{game_name}.png")
    portrait.save(out, "PNG")
    print(f"  Sauvegarde : {out}")
    return True


def main():
    os.makedirs(OUT_DIR, exist_ok=True)

    # Supprimer l'ancien Berouge
    old = os.path.join(OUT_DIR, "char_Berouge.png")
    if os.path.exists(old):
        os.remove(old)
        print("Supprime char_Berouge.png (renomme en Urouge)\n")

    ok = 0
    for i, (game_name, wiki_title) in enumerate(FIX.items(), 1):
        print(f"[{i}/{len(FIX)}]", end=" ")
        try:
            if process(game_name, wiki_title):
                ok += 1
        except Exception as e:
            print(f"  ERREUR : {e}")
        time.sleep(0.4)
        print()

    print(f"\nTermine : {ok}/{len(FIX)} portraits corriges.")

    # Verification globale
    print("\n--- Verification finale ---")
    bad = []
    for f in sorted(os.listdir(OUT_DIR)):
        if not f.startswith("char_") or not f.endswith(".png"):
            continue
        name = f[5:-4]
        img  = Image.open(f"{OUT_DIR}/{f}").convert("RGBA")
        vis  = sum(1 for px in img.getchannel("A").getdata() if px > 30)
        pct  = vis * 100 // (SIZE[0] * SIZE[1])
        if pct < 10:
            bad.append(f"{name} ({pct}%)")
    if bad:
        print(f"Toujours insuffisants : {bad}")
    else:
        print("Tous les portraits sont valides.")


if __name__ == "__main__":
    main()

/**
 * gen_assets.cpp — Portraits 128×128 reconnaissables pour Grand Line Legends.
 * Compile : g++ -std=c++11 -O2 tools/gen_assets.cpp -o tools/gen_assets -lm
 * Usage   : ./tools/gen_assets   (depuis grand-line-legends/)
 */

#include <cstdio>
#include <cstdint>
#include <cmath>
#include <cstring>
#include <vector>
#include <string>
#include <algorithm>
using namespace std;

#if defined(_WIN32)
#  include <direct.h>
#  define MKDIRP(p) _mkdir(p)
#else
#  include <sys/stat.h>
#  define MKDIRP(p) mkdir((p), 0755)
#endif

// ─── PNG encoder (CRC/Adler/zlib stored) ─────────────────────────────────────
static uint32_t g_crc[256];
static void initCRC(){for(uint32_t n=0;n<256;n++){uint32_t c=n;for(int k=0;k<8;k++)c=(c&1)?(0xEDB88320u^(c>>1)):(c>>1);g_crc[n]=c;}}
static uint32_t crcUpd(uint32_t c,const uint8_t*d,size_t n){for(size_t i=0;i<n;i++)c=g_crc[(c^d[i])&0xFF]^(c>>8);return c;}
static uint32_t adler32(const uint8_t*d,size_t n){uint32_t s1=1,s2=0;for(size_t i=0;i<n;i++){s1=(s1+d[i])%65521u;s2=(s2+s1)%65521u;}return(s2<<16)|s1;}
static void w32be(FILE*f,uint32_t v){uint8_t b[4]={(uint8_t)(v>>24),(uint8_t)(v>>16),(uint8_t)(v>>8),(uint8_t)v};fwrite(b,1,4,f);}
static void wchunk(FILE*f,const char*t,const uint8_t*d,uint32_t l){
    w32be(f,l);fwrite(t,1,4,f);if(l)fwrite(d,1,l,f);
    uint32_t c=crcUpd(0xFFFFFFFFu,(const uint8_t*)t,4);if(l)c=crcUpd(c,d,l);w32be(f,c^0xFFFFFFFFu);}
static vector<uint8_t> zstore(const uint8_t*data,size_t len){
    vector<uint8_t>o;o.push_back(0x78);o.push_back(0x01);
    size_t p=0;do{size_t r=len-p,c=r<65535?r:65535;bool l=(p+c>=len);
        o.push_back(l?1u:0u);uint16_t cl=(uint16_t)c,nc=(uint16_t)(~cl);
        o.push_back(cl&0xFF);o.push_back(cl>>8);o.push_back(nc&0xFF);o.push_back(nc>>8);
        for(size_t i=0;i<c;i++)o.push_back(data[p+i]);p+=c;}while(p<len);
    uint32_t a=adler32(data,len);o.push_back((a>>24)&0xFF);o.push_back((a>>16)&0xFF);o.push_back((a>>8)&0xFF);o.push_back(a&0xFF);return o;}

// ─── Image RGBA 128×128 ───────────────────────────────────────────────────────
static uint8_t clamp8(int v){return v<0?0:v>255?255:(uint8_t)v;}
static uint8_t ltr(uint8_t c,int d){return clamp8((int)c+d);}
static uint8_t drk(uint8_t c,int d){return clamp8((int)c-d);}

struct Img {
    int W,H; vector<uint8_t>px;
    Img(int w,int h):W(w),H(h),px(w*h*4,0){}
    void set(int x,int y,uint8_t r,uint8_t g,uint8_t b,uint8_t a=255){
        if(x<0||x>=W||y<0||y>=H)return;int i=(y*W+x)*4;px[i]=r;px[i+1]=g;px[i+2]=b;px[i+3]=a;}
    void rect(int x,int y,int w,int h,uint8_t r,uint8_t g,uint8_t b,uint8_t a=255){
        for(int dy=0;dy<h;dy++)for(int dx=0;dx<w;dx++)set(x+dx,y+dy,r,g,b,a);}
    void circle(int cx,int cy,int rad,uint8_t r,uint8_t g,uint8_t b,uint8_t a=255){
        for(int dy=-rad;dy<=rad;dy++)for(int dx=-rad;dx<=rad;dx++)
            if(dx*dx+dy*dy<=rad*rad)set(cx+dx,cy+dy,r,g,b,a);}
    void ellipse(int cx,int cy,int rx,int ry,uint8_t r,uint8_t g,uint8_t b,uint8_t a=255){
        if(rx<=0||ry<=0)return;
        for(int dy=-ry;dy<=ry;dy++)for(int dx=-rx;dx<=rx;dx++){
            float fx=(float)dx/rx, fy=(float)dy/ry;
            if(fx*fx+fy*fy<=1.f)set(cx+dx,cy+dy,r,g,b,a);}}
    void circleGrad(int cx,int cy,int rad,uint8_t r,uint8_t g,uint8_t b,uint8_t br,uint8_t bg_,uint8_t bb){
        for(int dy=-rad;dy<=rad;dy++)for(int dx=-rad;dx<=rad;dx++){
            float d=sqrtf((float)(dx*dx+dy*dy));
            if(d<=rad){float m=0.15f+(1.f-d/rad)*0.70f;
                set(cx+dx,cy+dy,(uint8_t)(r*m+br*(1-m)),(uint8_t)(g*m+bg_*(1-m)),(uint8_t)(b*m+bb*(1-m)));}}}
    void circleSphere(int cx,int cy,int rad,uint8_t r,uint8_t g,uint8_t b){
        for(int dy=-rad;dy<=rad;dy++)for(int dx=-rad;dx<=rad;dx++){
            float d=sqrtf((float)(dx*dx+dy*dy));
            if(d<=rad){
                // ombre sur les bords, léger reflet en haut-gauche
                float shade=1.f-(d/rad)*0.35f;
                float hlt=(dx<0&&dy<-rad/4)?0.15f:0.f;
                set(cx+dx,cy+dy,clamp8((int)(r*shade+255*hlt)),clamp8((int)(g*shade+255*hlt)),clamp8((int)(b*shade+255*hlt)));}}}
    void line(int x1,int y1,int x2,int y2,uint8_t r,uint8_t g,uint8_t b,int tk=1){
        int dx=abs(x2-x1),dy=abs(y2-y1),sx=x1<x2?1:-1,sy=y1<y2?1:-1,err=dx-dy,h2=tk/2;
        while(true){for(int ty=-h2;ty<=h2;ty++)for(int tx=-h2;tx<=h2;tx++)set(x1+tx,y1+ty,r,g,b);
            if(x1==x2&&y1==y2)break;int e2=2*err;if(e2>-dy){err-=dy;x1+=sx;}if(e2<dx){err+=dx;y1+=sy;}}}
    bool save(const char*path){
        FILE*f=fopen(path,"wb");if(!f){fprintf(stderr,"Erreur: %s\n",path);return false;}
        static const uint8_t SIG[8]={137,80,78,71,13,10,26,10};fwrite(SIG,1,8,f);
        uint8_t ih[13]={};ih[0]=(W>>24)&0xFF;ih[1]=(W>>16)&0xFF;ih[2]=(W>>8)&0xFF;ih[3]=W&0xFF;
        ih[4]=(H>>24)&0xFF;ih[5]=(H>>16)&0xFF;ih[6]=(H>>8)&0xFF;ih[7]=H&0xFF;ih[8]=8;ih[9]=6;
        wchunk(f,"IHDR",ih,13);
        size_t row=1+(size_t)W*4;vector<uint8_t>raw(H*row);
        for(int y=0;y<H;y++){raw[y*row]=0;for(int x=0;x<W;x++){size_t d=y*row+1+x*4,s=(y*W+x)*4;for(int c=0;c<4;c++)raw[d+c]=px[s+c];}}
        auto id=zstore(raw.data(),raw.size());wchunk(f,"IDAT",id.data(),(uint32_t)id.size());
        wchunk(f,"IEND",nullptr,0);fclose(f);printf("  %s\n",path);return true;}
};

// ─── Enums ────────────────────────────────────────────────────────────────────
// Chapeau
enum HatT {
    H_NONE=0, H_STRAW,      // chapeau de paille (Luffy, Fujitora)
    H_TOP,                   // haut-de-forme (Brook, Sabo)
    H_SPOTTED,               // casquette à pois (Law)
    H_MARINE,                // képi marine (Koby, Smoker, amiraux, Garp)
    H_PIRATE_CAP,            // bicorne pirate
    H_CROWN,                 // couronne (Vivi, Boa)
    H_ONI_HORNS,             // cornes d'oni (Yamato, Kaido)
    H_BIGMOM_HAT,            // chapeau tricorne (Big Mom)
    H_BERET,                 // béret (Berouge)
    H_FEATHER_COL,           // col de plumes (Doflamingo — sur les épaules)
    H_CROSS_HAT,             // chapeau croix de médecin (Chopper)
    H_CAGE_HELM              // casque-cage (Killer)
};

// Particularité visuelle
enum SpT {
    SP_NONE=0,
    SP_SKULL,         // visage de squelette (Brook)
    SP_BEAR,          // ours polaire (Bepo)
    SP_REINDEER,      // renne (Chopper)
    SP_FISHMAN,       // homme-poisson (Jinbe) — peau bleue + motifs
    SP_BIG_NOSE,      // nez immense (Usopp)
    SP_FRECKLES,      // taches de rousseur (Ace)
    SP_DRAGON_TAT,    // tatouage dragon (Dragon)
    SP_SPOTS,         // taches de léopard (Lucci)
    SP_RABBIT_EARS,   // oreilles de lapin (Carrot)
    SP_LIGHTNING,     // foudre / auréole (Ener)
    SP_RED_NOSE,      // nez rouge de clown (Baggy)
    SP_TEARS,         // traits de mascara (BonClay)
    SP_HUGE,          // corps/tête immense (Kaido, BigMom)
    SP_METAL_ARM,     // bras métal (Kid)
    SP_CYBORG         // bras cyborg bleu (Franky)
};

// Type de barbe
enum BrdT { BR_NONE=0, BR_STUBBLE, BR_BEARD, BR_HUGE_WHITE, BR_BLACK_MULTI };

// Cicatrice
enum ScrT { SC_NONE=0, SC_UNDER_L, SC_OVER_L, SC_OVER_R, SC_CROSS, SC_X_CHEST };

struct CharDef {
    const char* name;
    uint8_t aurR,aurG,aurB;      // halo
    int     skin;                 // 0=clair 1=mat 2=foncé 3=spécial(bleu/vert)
    uint8_t hR,hG,hB;            // couleur cheveux
    int     hairStyle;            // 0=court 1=moyen 2=long 3=hérissé 4=afro 5=chauve 6=pompadour
    HatT    hat;
    uint8_t hatR,hatG,hatB;
    uint8_t eyeR,eyeG,eyeB;
    SpT     sp;
    ScrT    scar;
    BrdT    beard;
    uint8_t outR,outG,outB;      // tenue
    int     typeIdx, rarIdx;
};

// ─── Données des 67 personnages ───────────────────────────────────────────────
// typeIdx : snp_=0 int_=1 mag_=2 atk_=3 def_=4 sup_=5
// rarIdx  : c=0 r=1 sr=2 e=3 l=4 m=5
static const CharDef CHARS[] = {
// Communs
//  name          aura            skin  cheveux         hs  hat             hatCol          eye             sp            scar      beard      tenue            ty  ra
{"Luffy",    200,40,40,    0,  20,20,20,     3, H_STRAW,   180,155,90,  100,180,220, SP_FRECKLES,  SC_UNDER_L, BR_NONE,   200,40,40,     3,0},
{"Zoro",      40,160,60,   0,  30,130,30,    0, H_NONE,      0,0,0,     50,160,80,  SP_NONE,      SC_OVER_L,  BR_NONE,    30,120,50,    3,0},
{"Sanji",    200,175,40,   0,  200,185,70,   1, H_NONE,      0,0,0,    160,120,50,  SP_NONE,      SC_NONE,    BR_NONE,    35,35,50,     3,0},
{"Brook",    180,175,205,  3,  20,20,20,     4, H_TOP,     30,30,40,   220,220,225, SP_SKULL,     SC_NONE,    BR_NONE,    35,35,50,     3,0},
{"Lucci",     80,50,110,   0,  20,20,20,     0, H_NONE,      0,0,0,     80,50,120,  SP_SPOTS,     SC_NONE,    BR_NONE,    45,35,65,     3,0},
{"Killer",   220,190,40,   0,  210,190,60,   0, H_CAGE_HELM,180,170,50, 220,190,60,  SP_NONE,      SC_NONE,    BR_NONE,   195,175,30,    3,0},
{"Usopp",    145,110,50,   1,  20,20,20,     4, H_NONE,      0,0,0,    100,80,40,   SP_BIG_NOSE,  SC_NONE,    BR_NONE,   120,90,50,     0,0},
{"Franky",    30,100,210,  0,  30,80,200,    6, H_NONE,      0,0,0,     30,100,210, SP_CYBORG,    SC_NONE,    BR_NONE,    20,80,185,    1,0},
{"Vivi",      70,155,215,  0,  50,110,215,   2, H_CROWN,   220,190,50, 100,180,230, SP_NONE,      SC_NONE,    BR_NONE,   215,215,230,   5,0},
{"Nami",     225,130,35,   0,  225,130,35,   1, H_NONE,      0,0,0,    180,130,60,  SP_NONE,      SC_NONE,    BR_NONE,   210,120,35,    1,0},
{"Koby",     210,140,165,  0,  210,140,165,  0, H_MARINE,  30,50,120,  180,140,165, SP_NONE,      SC_NONE,    BR_NONE,   200,205,215,   1,0},
{"BonClay",  150,70,175,   0,  20,20,20,     1, H_NONE,      0,0,0,    150,70,175,  SP_TEARS,     SC_NONE,    BR_NONE,   155,80,175,    5,0},
{"Baggy",    185,45,45,    0,  50,80,195,    0, H_PIRATE_CAP,50,70,180, 80,60,160,  SP_RED_NOSE,  SC_NONE,    BR_NONE,   175,50,50,     5,0},
{"Bepo",     210,210,225,  3,  205,205,220,  5, H_NONE,      0,0,0,    180,200,225, SP_BEAR,      SC_NONE,    BR_NONE,   200,205,220,   5,0},
{"Chopper",  210,90,90,    1,  145,90,55,    0, H_CROSS_HAT,190,105,105,200,90,90,  SP_REINDEER,  SC_NONE,    BR_NONE,   185,105,105,   5,0},
// Rares
{"Bege",      110,110,125, 0,  20,20,20,     0, H_PIRATE_CAP,55,55,70, 90,90,110,  SP_NONE,      SC_NONE,    BR_STUBBLE, 55,55,70,     4,1},
{"Urouge",   120,50,160,   2,  20,20,20,     5, H_NONE,      0,0,0,    120,50,160,  SP_HUGE,      SC_NONE,    BR_NONE,   100,40,130,    2,1},
{"Momonosuke",210,150,175, 0,  50,40,45,     1, H_NONE,      0,0,0,    100,80,130,  SP_NONE,      SC_NONE,    BR_NONE,   205,155,180,   4,1},
{"Burgess",   90,65,65,    0,  40,30,35,     0, H_CAGE_HELM,60,50,60,  80,60,65,    SP_HUGE,      SC_NONE,    BR_NONE,    60,55,60,     4,1},
{"Carrot",   225,165,55,   3,  220,215,195,  2, H_NONE,      0,0,0,    200,175,80,  SP_RABBIT_EARS,SC_NONE,  BR_NONE,   215,210,200,   3,1},
{"VanAugur",  55,65,130,   0,  40,45,65,     1, H_NONE,      0,0,0,     55,65,130,  SP_NONE,      SC_NONE,    BR_NONE,    50,55,80,     0,1},
{"Bonney",   210,110,150,  0,  210,110,150,  2, H_NONE,      0,0,0,    200,100,145, SP_NONE,      SC_NONE,    BR_NONE,   190,105,145,   2,1},
{"Appo",      85,65,105,   0,  40,35,55,     0, H_NONE,      0,0,0,     85,65,105,  SP_NONE,      SC_NONE,    BR_NONE,    70,55,90,     2,1},
{"Ivankov",  150,65,190,   0,  125,55,170,   4, H_NONE,      0,0,0,    150,65,190,  SP_NONE,      SC_NONE,    BR_NONE,   130,60,180,    5,1},
{"XDrake",   145,55,65,    0,  40,30,35,     1, H_PIRATE_CAP,50,75,145,100,55,65,   SP_NONE,      SC_NONE,    BR_STUBBLE, 50,75,140,    1,1},
{"GeckoMoria", 85,35,105,  3,  20,20,20,     0, H_NONE,      0,0,0,     85,35,105,  SP_NONE,      SC_NONE,    BR_NONE,    35,25,45,     2,1},
{"Izo",      185,165,190,  0,  210,205,220,  2, H_NONE,      0,0,0,    180,160,185, SP_NONE,      SC_NONE,    BR_NONE,   215,210,220,   0,1},
{"Smoker",   165,165,180,  0,  205,205,210,  0, H_MARINE,  30,50,120,  160,160,175, SP_NONE,      SC_NONE,    BR_STUBBLE,175,175,190,   5,1},
// Super rares
{"Jinbe",     45,65,170,   3,  25,45,120,    5, H_NONE,      0,0,0,     45,65,170,  SP_FISHMAN,   SC_NONE,    BR_NONE,    30,50,140,    1,2},
{"Robin",     85,55,135,   0,  20,20,20,     2, H_NONE,      0,0,0,     85,55,135,  SP_NONE,      SC_NONE,    BR_NONE,    65,50,105,    1,2},
{"Crocodile",165,135,35,   0,  20,20,20,     0, H_NONE,      0,0,0,    155,125,35,  SP_NONE,      SC_CROSS,   BR_NONE,   145,125,80,    1,2},
{"Kuma",      65,55,85,    2,  40,30,45,     5, H_NONE,      0,0,0,     65,55,85,   SP_NONE,      SC_NONE,    BR_NONE,    40,30,50,     4,2},
{"Kid",      185,45,45,    0,  165,45,45,    3, H_NONE,      0,0,0,    165,45,45,   SP_METAL_ARM, SC_NONE,    BR_NONE,   165,40,40,     3,2},
{"Yamato",   145,165,215,  0,  210,210,230,  2, H_ONI_HORNS,175,120,60, 145,165,215, SP_NONE,    SC_NONE,    BR_NONE,   155,185,215,   3,2},
{"BoaHancock",210,85,140,  0,  20,20,20,     2, H_CROWN,   220,190,50, 210,85,140,  SP_NONE,      SC_NONE,    BR_NONE,   190,75,115,    2,2},
{"Hawkins",  185,165,65,   0,  210,190,60,   2, H_NONE,      0,0,0,    185,165,65,  SP_NONE,      SC_NONE,    BR_NONE,   160,145,75,    2,2},
{"Ace",      230,125,35,   1,  20,20,20,     0, H_PIRATE_CAP,220,130,40,220,125,35,  SP_FRECKLES, SC_NONE,    BR_NONE,    0,0,0,        2,2},
{"Shiliew",   65,65,85,    0,  40,30,35,     0, H_NONE,      0,0,0,     65,65,85,   SP_NONE,      SC_NONE,    BR_STUBBLE, 50,55,70,     3,2},
{"Yasopp",   145,105,55,   0,  185,115,45,   1, H_PIRATE_CAP,50,90,175,140,100,55,  SP_NONE,     SC_NONE,    BR_NONE,    50,90,165,     0,2},
{"Doflamingo",210,105,135, 0,  210,185,65,   0, H_FEATHER_COL,215,90,130,80,60,180, SP_NONE,     SC_NONE,    BR_NONE,   190,90,120,    3,2},
// Épiques
{"Vegapunk", 165,190,215,  0,  210,205,220,  4, H_NONE,      0,0,0,    165,190,215, SP_NONE,      SC_NONE,    BR_NONE,   210,215,225,   1,3},
{"DoggyBroggy",125,95,55,  1,  100,80,45,    1, H_NONE,      0,0,0,    120,95,55,   SP_NONE,      SC_NONE,    BR_BEARD,  110,90,55,     4,3},
{"Zunesha",  130,130,145,  3,  130,130,150,  5, H_NONE,      0,0,0,    130,130,145, SP_HUGE,      SC_NONE,    BR_NONE,   125,125,140,   4,3},
{"Emeth",    145,135,125,  3,  70,65,75,     5, H_NONE,      0,0,0,    145,135,125, SP_NONE,      SC_NONE,    BR_NONE,   130,120,115,   4,3},
{"Fujitora", 110,65,155,   0,  50,45,55,     5, H_STRAW,   180,155,90, 220,220,220, SP_NONE,      SC_NONE,    BR_BEARD,   90,65,135,    3,3},
{"King",     105,55,35,    0,  20,20,20,     2, H_NONE,      0,0,0,    105,55,35,   SP_NONE,      SC_NONE,    BR_NONE,    45,35,55,     3,3},
{"Katakuri", 145,45,55,    0,  125,35,35,    3, H_NONE,      0,0,0,    145,45,55,   SP_HUGE,      SC_NONE,    BR_NONE,   130,40,55,     3,3},
{"BenBeckman",145,145,160, 0,  160,155,170,  1, H_PIRATE_CAP,50,90,175,140,140,155, SP_NONE,     SC_NONE,    BR_STUBBLE, 115,100,70,    0,3},
{"Ener",     230,210,45,   3,  210,205,220,  5, H_NONE,      0,0,0,    230,210,45,  SP_LIGHTNING, SC_NONE,    BR_NONE,   210,190,55,    0,3},
{"Ryokugyu",  55,170,65,   0,  30,105,35,    1, H_MARINE,  30,50,120,   55,170,65,  SP_NONE,      SC_NONE,    BR_NONE,    45,115,55,    2,3},
{"Marco",     55,105,215,  0,  210,185,65,   0, H_NONE,      0,0,0,     55,105,215, SP_NONE,      SC_NONE,    BR_NONE,    40,95,185,    5,3},
// Légendaires
{"Rayleigh", 145,115,45,   0,  145,135,125,  5, H_NONE,      0,0,0,    145,115,45,  SP_NONE,      SC_NONE,    BR_BEARD,   95,85,65,     1,4},
{"Law",       65,165,150,  0,  40,35,55,     0, H_SPOTTED,  230,225,215,65,165,150, SP_NONE,      SC_NONE,    BR_NONE,    55,55,75,     5,4},
{"Sengoku",  185,160,45,   0,  145,135,125,  4, H_MARINE,  30,50,120,  180,155,45,  SP_NONE,      SC_NONE,    BR_BEARD,   65,80,130,    4,4},
{"Akainu",   190,45,35,    0,  40,30,35,     0, H_MARINE,  30,50,120,  190,45,35,   SP_NONE,      SC_NONE,    BR_NONE,    50,40,50,     2,4},
{"Kizaru",   230,210,85,   0,  40,40,55,     0, H_MARINE,  30,50,120,  230,210,85,  SP_NONE,      SC_NONE,    BR_NONE,   190,190,205,   2,4},
{"Aokiji",   110,175,215,  0,  40,40,55,     0, H_MARINE,  30,50,120,  110,175,215, SP_NONE,      SC_NONE,    BR_NONE,    60,85,135,    2,4},
{"Sabo",     210,130,35,   0,  210,185,65,   1, H_TOP,     30,30,40,   180,130,55,  SP_NONE,      SC_NONE,    BR_NONE,    80,75,85,     2,4},
{"Crocus",    65,160,85,   0,  205,200,215,  0, H_NONE,      0,0,0,     65,160,85,  SP_NONE,      SC_NONE,    BR_BEARD,   80,145,85,    5,4},
// Mythiques
{"Shanks",   215,45,45,    0,  210,60,55,    2, H_NONE,      0,0,0,    215,45,45,   SP_NONE,      SC_OVER_L,  BR_NONE,   170,45,45,     3,5},
{"Garp",      55,65,135,   0,  80,75,75,     5, H_MARINE,  30,50,120,   55,65,135,  SP_NONE,      SC_NONE,    BR_STUBBLE, 55,75,135,    3,5},
{"Dragon",    55,85,65,    0,  40,55,45,     1, H_NONE,      0,0,0,     55,85,65,   SP_DRAGON_TAT,SC_NONE,   BR_NONE,    40,65,50,     2,5},
{"Mihawk",    65,55,85,    0,  40,30,45,     1, H_NONE,      0,0,0,     65,55,85,   SP_NONE,      SC_CROSS,   BR_BEARD,   45,40,60,     3,5},
{"Kaido",     85,55,130,   0,  60,45,85,     2, H_ONI_HORNS,120,40,40,  85,55,130,  SP_HUGE,     SC_NONE,    BR_NONE,    60,45,85,     3,5},
{"BigMom",   215,85,130,   0,  190,85,105,   4, H_BIGMOM_HAT,200,80,120,215,85,130, SP_HUGE,    SC_NONE,    BR_NONE,   160,75,105,    5,5},
{"BarbeNoire",45,35,60,    0,  20,20,20,     3, H_PIRATE_CAP,30,25,45,  45,35,60,  SP_NONE,     SC_NONE,    BR_BLACK_MULTI,35,30,50,   2,5},
{"BarbeBlanche",210,205,220,0, 210,205,220,  5, H_NONE,      0,0,0,    210,205,220, SP_NONE,    SC_X_CHEST, BR_HUGE_WHITE,80,80,95,    3,5},
};
static const int NB_CHARS=(int)(sizeof(CHARS)/sizeof(CHARS[0]));

// ─── Génération portrait 128×128 ─────────────────────────────────────────────
static void genChar(const CharDef& cd)
{
    char path[256];
    snprintf(path,sizeof(path),"assets/char_%s.png",cd.name);

    const int W=128, H=128;
    Img img(W,H);

    // Coordonnées du visage
    const int FX=64, FY=80, FR=24;  // centre, rayon

    // Couleur de peau
    uint8_t skR,skG,skB;
    switch(cd.skin){
        case 1: skR=200;skG=162;skB=122;break;
        case 2: skR=152;skG=108;skB=72; break;
        case 3: skR=cd.aurR/2+40;skG=cd.aurG/2+40;skB=cd.aurB/2+60;break; // spécial (bleu etc)
        default:skR=228;skG=192;skB=155;break;
    }
    // Couleur iris (dérivée de l'aura)
    uint8_t irR=drk(cd.aurR,30), irG=drk(cd.aurG,30), irB=drk(cd.aurB,30);
    // Cheveux
    uint8_t hR=cd.hR, hG=cd.hG, hB=cd.hB;

    // ── 1. Fond + halo ────────────────────────────────────────────────────────
    img.rect(0,0,W,H,15,15,30);
    img.circleGrad(FX,FY+5,58,cd.aurR,cd.aurG,cd.aurB,15,15,30);

    // ── 2. Tenue / épaules ───────────────────────────────────────────────────
    // Cou
    img.rect(FX-6,FY+FR-2,12,10,skR,skG,skB);
    // Épaules larges
    img.rect(FX-30,FY+FR+7,60,13,cd.outR,cd.outG,cd.outB);
    img.rect(FX-24,FY+FR+19,48,8, drk(cd.outR,20),drk(cd.outG,20),drk(cd.outB,20));
    // Reflet tenue
    img.rect(FX-18,FY+FR+8,8,10,ltr(cd.outR,40),ltr(cd.outG,40),ltr(cd.outB,40));
    // Contour tenue
    img.rect(FX-30,FY+FR+7,60,1, drk(cd.outR,40),drk(cd.outG,40),drk(cd.outB,40));

    // Tenue spéciale : Ace = torse nu
    if(cd.sp == SP_FRECKLES && cd.typeIdx == 2) {
        img.rect(FX-24,FY+FR+8,48,18,skR,skG,skB);
    }

    // ── 3. Col de plumes (Doflamingo) ────────────────────────────────────────
    if(cd.hat == H_FEATHER_COL){
        // Col rose volumeux sur les épaules
        uint8_t fr=cd.hatR, fg=cd.hatG, fb=cd.hatB;
        for(int i=0;i<12;i++){
            int fx2=FX-32+i*6, fy2=FY+FR+4;
            img.ellipse(fx2,fy2,5,8,fr,fg,fb);
            img.ellipse(fx2,fy2,3,5,ltr(fr,30),ltr(fg,30),ltr(fb,30));
        }
        // Lunettes rondes
        img.circle(FX-8,FY-4,5,drk(cd.hatR,60),drk(cd.hatG,60),drk(cd.hatB,60));
        img.circle(FX+8,FY-4,5,drk(cd.hatR,60),drk(cd.hatG,60),drk(cd.hatB,60));
        img.rect(FX-3,FY-4,6,2,drk(cd.hatR,60),drk(cd.hatG,60),drk(cd.hatB,60));
        img.circle(FX-8,FY-4,3,80,70,100);
        img.circle(FX+8,FY-4,3,80,70,100);
    }

    // ── 4. Oreilles ──────────────────────────────────────────────────────────
    if(cd.sp!=SP_BEAR && cd.sp!=SP_REINDEER && cd.sp!=SP_RABBIT_EARS && cd.sp!=SP_SKULL){
        img.circle(FX-FR,FY+3,5,skR,skG,skB);
        img.circle(FX+FR,FY+3,5,skR,skG,skB);
        img.circle(FX-FR,FY+3,2,drk(skR,25),drk(skG,25),drk(skB,25));
        img.circle(FX+FR,FY+3,2,drk(skR,25),drk(skG,25),drk(skB,25));
    }
    // Oreilles de lapin (Carrot)
    if(cd.sp==SP_RABBIT_EARS){
        img.ellipse(FX-12,FY-FR-22,6,20,230,225,210);
        img.ellipse(FX+12,FY-FR-22,6,20,230,225,210);
        img.ellipse(FX-12,FY-FR-22,3,14,220,170,175);
        img.ellipse(FX+12,FY-FR-22,3,14,220,170,175);
    }

    // ── 5. Cheveux (derrière le visage) ──────────────────────────────────────
    uint8_t hdR=drk(hR,40),hdG=drk(hG,40),hdB=drk(hB,40);
    uint8_t hlR=ltr(hR,55),hlG=ltr(hG,55),hlB=ltr(hB,55);

    switch(cd.hairStyle){
        case 0: { // court
            img.rect(FX-16,FY-FR-7,32,10,hR,hG,hB);
            img.rect(FX-18,FY-FR,5,14, hR,hG,hB);
            img.rect(FX+13,FY-FR,5,14, hR,hG,hB);
            img.rect(FX-16,FY-FR+3,32,3, hdR,hdG,hdB);
            img.rect(FX+4,FY-FR-6,8,4, hlR,hlG,hlB);
            break; }
        case 1: { // moyen
            img.rect(FX-18,FY-FR-16,36,18,hR,hG,hB);
            img.rect(FX-20,FY-FR-8, 6,22,hR,hG,hB);
            img.rect(FX+14,FY-FR-8, 6,22,hR,hG,hB);
            img.rect(FX-18,FY-FR+1,36,3, hdR,hdG,hdB);
            img.rect(FX+4, FY-FR-13,10,6, hlR,hlG,hlB);
            break; }
        case 2: { // long
            img.rect(FX-19,FY-FR-22,38,24,hR,hG,hB);
            img.rect(FX-21,FY-FR-12, 7,38,hR,hG,hB);
            img.rect(FX+14,FY-FR-12, 7,38,hR,hG,hB);
            img.rect(FX-19,FY-FR+1,38,3, hdR,hdG,hdB);
            img.rect(FX+5, FY-FR-18,10,7, hlR,hlG,hlB);
            break; }
        case 3: { // hérissé / spiky
            int ht[9]={8,14,20,25,28,25,20,14,8};
            for(int s=0;s<9;s++){
                int bx=FX-18+s*4;
                img.rect(bx,FY-FR-ht[s],4,ht[s]+5,hR,hG,hB);
                img.rect(bx,FY-FR-ht[s],4,3,hdR,hdG,hdB);
                img.set(bx+3,FY-FR-ht[s]+3,hlR,hlG,hlB);
                img.set(bx+3,FY-FR-ht[s]+4,hlR,hlG,hlB);
            }
            img.rect(FX-19,FY-FR-6,38,8,hR,hG,hB);
            break; }
        case 4: { // afro / gros
            img.circle(FX,FY-FR-5,22,hR,hG,hB);
            img.circle(FX+8,FY-FR-14,6,hlR,hlG,hlB);
            // ombre base afro
            for(int dy=-4;dy<=4;dy++)for(int dx=-20;dx<=20;dx++)
                if(dx*dx+dy*dy<=20*20)img.set(FX+dx,FY-FR-2+dy,hdR,hdG,hdB);
            break; }
        case 5: { // chauve
            uint8_t sr=drk(skR,35),sg=drk(skG,35),sb=drk(skB,35);
            for(int dy=-FR;dy<=-FR/3;dy++)for(int dx=-12;dx<=12;dx++)
                if(dx*dx+dy*dy<=FR*FR)img.set(FX+dx,FY+dy,sr,sg,sb);
            break; }
        case 6: { // pompadour bleu (Franky)
            img.rect(FX-20,FY-FR-30,40,32,hR,hG,hB);
            img.ellipse(FX,FY-FR-22,22,16,hR,hG,hB);
            img.rect(FX-16,FY-FR-28,32,8,hdR,hdG,hdB);
            img.rect(FX-4, FY-FR-26,16,12,hlR,hlG,hlB);
            break; }
        default: break;
    }

    // ── 6. Chapeaux ──────────────────────────────────────────────────────────
    uint8_t hcR=cd.hatR, hcG=cd.hatG, hcB=cd.hatB;

    if(cd.hat == H_STRAW){
        // Chapeau de paille iconic (Luffy / Fujitora)
        // Bord large
        img.ellipse(FX,FY-FR-8,44,8,drk(hcR,20),drk(hcG,20),drk(hcB,20));
        img.ellipse(FX,FY-FR-8,42,6,hcR,hcG,hcB);
        // Dôme
        img.ellipse(FX,FY-FR-22,28,18,hcR,hcG,hcB);
        // Bande rouge
        img.rect(FX-26,FY-FR-12,52,4,185,40,40);
        // Texture (lignes)
        img.line(FX-25,FY-FR-8,FX-28,FY-FR-24,drk(hcR,30),drk(hcG,30),drk(hcB,30));
        img.line(FX+25,FY-FR-8,FX+28,FY-FR-24,drk(hcR,30),drk(hcG,30),drk(hcB,30));
        // Reflet
        img.ellipse(FX-8,FY-FR-24,10,5,ltr(hcR,50),ltr(hcG,50),ltr(hcB,50));
    }
    else if(cd.hat == H_TOP){
        // Haut-de-forme (Brook, Sabo)
        // Bord
        img.rect(FX-22,FY-FR-4,44,5,hcR,hcG,hcB);
        img.rect(FX-22,FY-FR-4,44,2,drk(hcR,30),drk(hcG,30),drk(hcB,30));
        // Corps
        img.rect(FX-15,FY-FR-38,30,36,hcR,hcG,hcB);
        img.rect(FX-15,FY-FR-38,30,3,drk(hcR,30),drk(hcG,30),drk(hcB,30));
        // Reflet latéral
        img.rect(FX-14,FY-FR-36,4,30,ltr(hcR,25),ltr(hcG,25),ltr(hcB,25));
        // Ruban
        img.rect(FX-15,FY-FR-10,30,3,drk(hcR,10),drk(hcG,10),drk(hcB,10));
    }
    else if(cd.hat == H_SPOTTED){
        // Casquette à pois (Law)
        img.ellipse(FX,FY-FR-14,26,16,hcR,hcG,hcB);
        // Visière
        img.rect(FX-24,FY-FR-4,48,6,drk(hcR,40),drk(hcG,40),drk(hcB,40));
        img.rect(FX-22,FY-FR-4,44,3,drk(hcR,30),drk(hcG,30),drk(hcB,30));
        // Pois noirs
        int px2[]={FX-14,FX-4,FX+8,FX-10,FX+4};
        int py[]={FY-FR-22,FY-FR-24,FY-FR-20,FY-FR-14,FY-FR-13};
        for(int i=0;i<5;i++) img.circle(px2[i],py[i],3,30,30,40);
        // Lettre "D" en blanc
        img.rect(FX-4,FY-FR-22,8,10,240,240,240);
        img.rect(FX,FY-FR-22,5,10,drk(hcR,10),drk(hcG,10),drk(hcB,10));
    }
    else if(cd.hat == H_MARINE){
        // Képi marine
        img.ellipse(FX,FY-FR-10,26,12,hcR,hcG,hcB);
        img.rect(FX-22,FY-FR-4,44,6,drk(hcR,20),drk(hcG,20),drk(hcB,20));
        // Emblème ancre
        img.circle(FX,FY-FR-12,4,245,240,220);
        img.line(FX,FY-FR-16,FX,FY-FR-8,30,30,100,2);
        img.line(FX-4,FY-FR-14,FX+4,FY-FR-14,30,30,100,1);
        // Bande blanche
        img.rect(FX-22,FY-FR-6,44,2,240,240,245);
    }
    else if(cd.hat == H_PIRATE_CAP){
        // Bicorne de pirate
        // Base
        img.ellipse(FX,FY-FR-10,28,14,hcR,hcG,hcB);
        // Pointes latérales
        img.ellipse(FX-26,FY-FR-8,10,6,hcR,hcG,hcB);
        img.ellipse(FX+26,FY-FR-8,10,6,hcR,hcG,hcB);
        img.rect(FX-32,FY-FR-10,64,6,hcR,hcG,hcB);
        // Tête de mort (Jolly Roger)
        img.circle(FX,FY-FR-14,5,240,235,225);
        img.circle(FX,FY-FR-14,3,hcR,hcG,hcB);  // cavités yeux
        img.set(FX-2,FY-FR-13,240,235,225);
        img.set(FX+2,FY-FR-13,240,235,225);
        // Contours
        for(int ix=-28;ix<=28;ix+=2) img.set(FX+ix,FY-FR-4,drk(hcR,30),drk(hcG,30),drk(hcB,30));
    }
    else if(cd.hat == H_CROWN){
        // Couronne d'or
        uint8_t gR=225,gG=190,gB=50;
        // Base
        img.rect(FX-20,FY-FR-4,40,7,gR,gG,gB);
        // Pointes
        int pts[]={-18,-10,0,10,18};
        int pth[]={16,22,26,22,16};
        for(int i=0;i<5;i++){
            img.rect(FX+pts[i]-2,FY-FR-3-pth[i],4,pth[i],gR,gG,gB);
            img.circle(FX+pts[i],FY-FR-4-pth[i],3,220,45,45);  // gemme rouge
        }
        img.rect(FX-20,FY-FR,40,2,drk(gR,40),drk(gG,40),drk(gB,40));
    }
    else if(cd.hat == H_ONI_HORNS){
        // Cornes d'oni (Yamato/Kaido)
        // Corne gauche
        for(int i=0;i<22;i++){
            int w2=6-i/4;
            if(w2<1)w2=1;
            int cx2=FX-15-(i/3), cy2=FY-FR-6-i;
            img.rect(cx2-w2,cy2,w2*2,2,hcR,hcG,hcB);
        }
        // Corne droite
        for(int i=0;i<22;i++){
            int w2=6-i/4;
            if(w2<1)w2=1;
            int cx2=FX+15+(i/3), cy2=FY-FR-6-i;
            img.rect(cx2-w2,cy2,w2*2,2,hcR,hcG,hcB);
        }
    }
    else if(cd.hat == H_BIGMOM_HAT){
        // Tricorne de Big Mom
        img.ellipse(FX,FY-FR-6,34,12,hcR,hcG,hcB);
        img.ellipse(FX,FY-FR-20,18,16,hcR,hcG,hcB);
        // Décoration
        img.circle(FX,FY-FR-32,5,220,190,50);
        img.circle(FX-16,FY-FR-20,4,200,60,90);
        img.circle(FX+16,FY-FR-20,4,200,60,90);
        img.rect(FX-32,FY-FR-8,64,4,drk(hcR,20),drk(hcG,20),drk(hcB,20));
    }
    else if(cd.hat == H_BERET){
        // Béret
        img.ellipse(FX-5,FY-FR-12,22,14,hcR,hcG,hcB);
        img.rect(FX-15,FY-FR-3,30,4,drk(hcR,25),drk(hcG,25),drk(hcB,25));
        img.circle(FX+10,FY-FR-14,3,ltr(hcR,30),ltr(hcG,30),ltr(hcB,30));
    }
    else if(cd.hat == H_CROSS_HAT){
        // Chapeau de Chopper (bleu avec croix rouge)
        img.ellipse(FX,FY-FR-12,26,14,10,60,160);
        img.rect(FX-24,FY-FR-3,48,5,drk(10,0),drk(60,0),drk(160,0));
        // Croix rouge
        img.rect(FX-2,FY-FR-22,4,14,200,30,30);
        img.rect(FX-7,FY-FR-16,14,4,200,30,30);
    }
    else if(cd.hat == H_CAGE_HELM){
        // Casque-cage (Killer)
        img.circle(FX,FY-FR+4,FR+6,hcR,hcG,hcB);
        // Barreaux
        for(int i=-3;i<=3;i++) img.line(FX+i*7,FY-FR-10,FX+i*7,FY+FR-4,drk(hcR,50),drk(hcG,50),drk(hcB,50),2);
        img.line(FX-FR-4,FY-6,FX+FR+4,FY-6,drk(hcR,50),drk(hcG,50),drk(hcB,50),2);
        // Cheveux blonds qui dépassent
        img.rect(FX-20,FY-FR-18,40,15,cd.hR,cd.hG,cd.hB);
    }

    // ── 7. Particularités spéciales (avant visage) ───────────────────────────
    if(cd.sp == SP_BEAR){
        // Ours polaire (Bepo) — visage rond blanc
        img.circle(FX,FY,FR+4,230,230,240);
        // Oreilles d'ours
        img.circle(FX-FR-2,FY-FR+2,8,220,220,235);
        img.circle(FX+FR+2,FY-FR+2,8,220,220,235);
        img.circle(FX-FR-2,FY-FR+2,4,200,180,185);
        img.circle(FX+FR+2,FY-FR+2,4,200,180,185);
        // Museau
        img.ellipse(FX,FY+10,8,5,200,195,210);
        img.circle(FX,FY+8,2,40,30,50);
        // Yeux ronds
        img.circle(FX-9,FY-4,4,20,20,30);
        img.circle(FX+9,FY-4,4,20,20,30);
        img.circle(FX-8,FY-5,2,240,240,255);
        img.circle(FX+8,FY-5,2,240,240,255);
        img.save(path); return;
    }
    if(cd.sp == SP_REINDEER){
        // Chopper — renne
        // Bois/bois de cerf
        img.line(FX-14,FY-FR,FX-24,FY-FR-28,100,70,40,2);
        img.line(FX-24,FY-FR-28,FX-30,FY-FR-18,100,70,40,2);
        img.line(FX-24,FY-FR-28,FX-16,FY-FR-20,100,70,40,2);
        img.line(FX+14,FY-FR,FX+24,FY-FR-28,100,70,40,2);
        img.line(FX+24,FY-FR-28,FX+30,FY-FR-18,100,70,40,2);
        img.line(FX+24,FY-FR-28,FX+16,FY-FR-20,100,70,40,2);
        // Visage marron
        img.circleSphere(FX,FY,FR,145,90,55);
        // Nez bleu (TRÈS distinctif)
        img.circle(FX,FY+10,7,30,100,220);
        img.circle(FX-1,FY+8,2,120,170,240);
        // Oreilles
        img.circle(FX-FR,FY,5,145,90,55);
        img.circle(FX+FR,FY,5,145,90,55);
        // Yeux noirs expressifs
        img.circle(FX-8,FY-5,5,20,20,30);
        img.circle(FX+8,FY-5,5,20,20,30);
        img.circle(FX-7,FY-7,2,240,240,250);
        img.circle(FX+9,FY-7,2,240,240,250);
        // Chapeau avec croix
        img.ellipse(FX,FY-FR-12,26,14,10,60,160);
        img.rect(FX-24,FY-FR-3,48,5,8,50,140);
        img.rect(FX-2,FY-FR-22,4,14,200,30,30);
        img.rect(FX-7,FY-FR-16,14,4,200,30,30);
        img.save(path); return;
    }

    // ── 8. Visage sphérique ───────────────────────────────────────────────────
    if(cd.sp == SP_SKULL){
        // Crâne de Brook
        img.circleSphere(FX,FY,FR,220,215,210);
        // Orbites vides
        img.circle(FX-9,FY-5,6,20,18,25);
        img.circle(FX+9,FY-5,6,20,18,25);
        // Nez (juste un triangle/trou)
        img.set(FX,FY+4,50,45,55); img.set(FX-1,FY+4,50,45,55);
        // Dents
        for(int i=0;i<6;i++) img.rect(FX-9+i*4,FY+10,3,6,235,230,225);
        for(int i=0;i<5;i++) img.rect(FX-7+i*4,FY+9,4,1,60,55,65);
        // Contour crâne
        for(int dy=-FR;dy<=FR;dy++)for(int dx=-FR;dx<=FR;dx++){
            float d=sqrtf((float)(dx*dx+dy*dy));
            if(d>FR-1.5f&&d<=FR)img.set(FX+dx,FY+dy,drk(220,30),drk(215,30),drk(210,30));}
    } else if(cd.sp == SP_FISHMAN){
        // Jinbe — peau bleue + motifs
        img.circleSphere(FX,FY,FR,cd.aurR/2+40,cd.aurG/2+40,cd.aurB/2+60);
        // Motifs de requin-baleine
        for(int i=0;i<5;i++){
            img.circle(FX-14+i*7,FY-8,3,drk(skR,30),drk(skG,30),drk(skB,30));}
        img.circle(FX-8,FY+5,4,drk(skR,25),drk(skG,25),drk(skB,25));
        img.circle(FX+8,FY+5,4,drk(skR,25),drk(skG,25),drk(skB,25));
    } else {
        img.circleSphere(FX,FY,FR,skR,skG,skB);
    }

    // Contour visage
    for(int dy=-FR;dy<=FR;dy++)for(int dx=-FR;dx<=FR;dx++){
        float d=sqrtf((float)(dx*dx+dy*dy));
        if(d>FR-1.5f&&d<=FR)img.set(FX+dx,FY+dy,drk(skR,35),drk(skG,35),drk(skB,35));}

    // ── 9. Sourcils ──────────────────────────────────────────────────────────
    uint8_t brR=drk(hR,20), brG=drk(hG,20), brB=drk(hB,20);
    if(brR<30&&brG<30&&brB<30){brR=60;brG=50;brB=50;}
    img.rect(FX-14,FY-12,8,2,brR,brG,brB);
    img.rect(FX+6, FY-12,8,2,brR,brG,brB);
    img.set(FX-15,FY-11,brR,brG,brB);
    img.set(FX+14, FY-11,brR,brG,brB);

    // Sourcil tourbillonnant de Sanji
    if(cd.hairStyle==1 && cd.hR>180 && cd.hG>150) {
        // sourcil gauche normal + droit en spirale
        img.circle(FX+10,FY-11,3,brR,brG,brB);
        img.set(FX+13,FY-12,brR,brG,brB);
    }

    // ── 10. Yeux ─────────────────────────────────────────────────────────────
    if(cd.sp != SP_SKULL && cd.sp != SP_BEAR && cd.sp != SP_REINDEER){
        // Sclère
        img.circle(FX-9,FY-5,5,240,235,220);
        img.circle(FX+9,FY-5,5,240,235,220);
        // Iris coloré
        img.circle(FX-9,FY-5,3,irR,irG,irB);
        img.circle(FX+9,FY-5,3,irR,irG,irB);
        // Pupille
        img.circle(FX-9,FY-5,2,20,18,25);
        img.circle(FX+9,FY-5,2,20,18,25);
        // Reflet
        img.set(FX-10,FY-7,255,255,255);
        img.set(FX+8, FY-7,255,255,255);

        // Couvrir l'oeil droit pour Sanji (cheveux)
        if(cd.hairStyle==1 && cd.hR>170 && cd.hG>145){
            img.circle(FX+9,FY-5,6,hR,hG,hB);
        }
        // Yeux aveugles de Fujitora (bandé)
        if(cd.hat==H_STRAW && cd.hairStyle==5){
            img.rect(FX-16,FY-8,32,6,200,175,145);  // bandeau
            img.rect(FX-16,FY-9,32,2,drk(200,30),drk(175,30),drk(145,30));
        }
    }

    // ── 11. Nez ──────────────────────────────────────────────────────────────
    if(cd.sp == SP_BIG_NOSE){
        // Nez TRÈS long d'Usopp
        img.rect(FX,FY+2,22,4,drk(skR,20),drk(skG,20),drk(skB,20));
        img.rect(FX,FY+3,20,3,drk(skR,15),drk(skG,15),drk(skB,15));
        img.circle(FX+22,FY+4,4,drk(skR,20),drk(skG,20),drk(skB,20));
    } else if(cd.sp == SP_RED_NOSE){
        // Nez rouge de Baggy
        img.circle(FX,FY+4,8,215,40,40);
        img.circle(FX-2,FY+2,3,240,100,100);
    } else {
        img.set(FX-1,FY+4,drk(skR,30),drk(skG,30),drk(skB,30));
        img.set(FX+1,FY+4,drk(skR,30),drk(skG,30),drk(skB,30));
        img.set(FX,  FY+5,drk(skR,35),drk(skG,35),drk(skB,35));
    }

    // ── 12. Bouche / sourire ──────────────────────────────────────────────────
    // Luffy a un grand sourire
    if(cd.typeIdx==3 && cd.rarIdx==0 && cd.sp==SP_FRECKLES){
        // Grand sourire de Luffy
        for(int i=-7;i<=7;i++) img.set(FX+i,FY+12+(i*i)/12,drk(skR,50),drk(skG,50),drk(skB,50));
        img.line(FX-5,FY+14,FX+5,FY+14,240,235,225,1);  // dents
    } else {
        // Sourire standard
        for(int i=-5;i<=5;i++) img.set(FX+i,FY+11+(i*i)/10,drk(skR,45),drk(skG,45),drk(skB,45));
    }

    // Cigare de Sanji
    if(cd.hairStyle==1 && cd.hR>170 && cd.hG>145){
        img.rect(FX+4,FY+11,12,3,200,190,175);
        img.circle(FX+16,FY+12,2,215,100,30);
        img.set(FX+16,FY+10,220,215,200);
    }

    // ── 13. Cicatrices ───────────────────────────────────────────────────────
    switch(cd.scar){
        case SC_UNDER_L:
            // Cicatrice sous l'œil gauche (Luffy)
            img.line(FX-9,FY-1,FX-7,FY+4,190,80,80,2);
            break;
        case SC_OVER_L:
            // Cicatrice sur l'œil gauche (Zoro, Shanks)
            img.line(FX-12,FY-11,FX-5,FY-2,190,80,80,2);
            break;
        case SC_OVER_R:
            img.line(FX+5,FY-11,FX+12,FY-2,190,80,80,2);
            break;
        case SC_CROSS:
            // Croix sur le visage (Crocodile, Mihawk)
            img.line(FX-4,FY-8,FX+4,FY+6,190,80,80,2);
            img.line(FX+4,FY-8,FX-4,FY+6,190,80,80,2);
            break;
        case SC_X_CHEST:
            // X sur la poitrine (Barbe Blanche)
            img.line(FX-15,FY+FR+8,FX+15,FY+FR+22,220,80,80,3);
            img.line(FX+15,FY+FR+8,FX-15,FY+FR+22,220,80,80,3);
            break;
        default: break;
    }

    // ── 14. Particularités supplémentaires ───────────────────────────────────
    if(cd.sp == SP_FRECKLES){
        // Taches de rousseur (Luffy, Ace)
        for(int i=0;i<5;i++){
            int fx2=FX-8+i*4, fy2=FY-2;
            img.set(fx2,fy2,drk(skR,40),drk(skG,40),drk(skB,40));
        }
        for(int i=0;i<5;i++){
            int fx2=FX-6+i*3, fy2=FY+1;
            img.set(fx2,fy2,drk(skR,35),drk(skG,35),drk(skB,35));
        }
    }
    if(cd.sp == SP_DRAGON_TAT){
        // Tatouage dragon sur le visage gauche (Dragon)
        img.line(FX-20,FY-10,FX-8,FY+8,140,40,40,2);
        img.line(FX-18,FY-8,FX-12,FY-2,140,40,40,2);
        img.line(FX-16,FY-4,FX-8,FY+12,120,35,35,2);
    }
    if(cd.sp == SP_SPOTS){
        // Taches de léopard (Lucci)
        int sx[]={FX-12,FX+5,FX-6,FX+9,FX-2};
        int sy[]={FY-8,FY-6,FY+2,FY+2,FY-14};
        for(int i=0;i<5;i++) img.circle(sx[i],sy[i],2,drk(skR,50),drk(skG,50),drk(skB,50));
    }
    if(cd.sp == SP_TEARS){
        // Traits de mascara (BonClay)
        img.line(FX-9,FY-2,FX-11,FY+8,20,20,100,2);
        img.line(FX+9,FY-2,FX+11,FY+8,20,20,100,2);
        // Maquillage
        img.rect(FX-13,FY-8,8,3,120,30,140);
        img.rect(FX+5, FY-8,8,3,120,30,140);
    }
    if(cd.sp == SP_LIGHTNING){
        // Foudre autour de la tête (Ener)
        for(int i=0;i<6;i++){
            float ang=(float)i*3.14159f/3.f;
            int lx=FX+(int)(cosf(ang)*32), ly=FY-10+(int)(sinf(ang)*28);
            img.line(FX+(int)(cosf(ang)*(FR+4)),FY-5+(int)(sinf(ang)*(FR+4)),lx,ly,230,210,50,2);
        }
    }
    if(cd.sp == SP_METAL_ARM){
        // Bras métal (Kid) — remplace l'épaule droite
        img.rect(FX+10,FY+FR+8,24,14,150,150,165);
        img.rect(FX+12,FY+FR+9,8,12,170,170,185);
        img.rect(FX+24,FY+FR+8,4,14,130,130,145);
    }
    if(cd.sp == SP_CYBORG){
        // Bras cyborg (Franky) — épaules argent
        img.rect(FX-30,FY+FR+8,14,12,160,165,180);
        img.rect(FX+16,FY+FR+8,14,12,160,165,180);
        img.rect(FX-28,FY+FR+9,6,8, 200,205,215);
        img.rect(FX+22,FY+FR+9,6,8, 200,205,215);
        // Étoile sur le torse
        img.circle(FX,FY+FR+12,4,220,185,30);
    }

    // ── 15. Barbe / moustache ─────────────────────────────────────────────────
    switch(cd.beard){
        case BR_STUBBLE:
            for(int i=-10;i<=10;i+=2) img.set(FX+i,FY+15,drk(skR,50),drk(skG,50),drk(skB,50));
            break;
        case BR_BEARD:{
            uint8_t bR=drk(hR,15),bG=drk(hG,15),bB=drk(hB,15);
            img.ellipse(FX,FY+16,12,6,bR,bG,bB);
            img.rect(FX-8,FY+13,16,6,bR,bG,bB);
            break;}
        case BR_HUGE_WHITE:{
            // Moustache en croissant de Barbe Blanche
            img.ellipse(FX,FY+6,18,6,220,215,210);
            img.ellipse(FX-16,FY+5,5,5,220,215,210);
            img.ellipse(FX+16,FY+5,5,5,220,215,210);
            img.ellipse(FX,FY+8,20,5,drk(220,20),drk(215,20),drk(210,20));
            break;}
        case BR_BLACK_MULTI:{
            // Barbe multi-touffes (Barbe Noire)
            for(int t=0;t<5;t++){
                int bx=FX-18+t*9;
                img.ellipse(bx,FY+18,4,7,30,25,35);
            }
            img.rect(FX-18,FY+12,36,7,30,25,35);
            break;}
        default: break;
    }

    // ── 16. Mèches de cheveux devant le visage ───────────────────────────────
    if(cd.hairStyle==2){
        img.line(FX-FR+4,FY-FR+4,FX-FR,FY+8,hR,hG,hB,3);
        img.line(FX+FR-4,FY-FR+4,FX+FR,FY+8,hR,hG,hB,3);
    }
    if(cd.hairStyle==1){
        // Mèche latérale courte
        img.line(FX-FR+2,FY-2,FX-FR+4,FY+6,hR,hG,hB,3);
    }

    // ── 17. Bordure de rareté ─────────────────────────────────────────────────
    static const uint8_t rarCol[6][3]={
        {120,120,130},{80,160,210},{220,180,50},{160,50,220},{220,160,30},{220,50,50}};
    auto* rc=rarCol[cd.rarIdx];
    // Cadre
    for(int x=0;x<W;x++){img.set(x,0,rc[0],rc[1],rc[2]);img.set(x,1,rc[0],rc[1],rc[2]);
                          img.set(x,H-1,rc[0],rc[1],rc[2]);img.set(x,H-2,rc[0],rc[1],rc[2]);}
    for(int y=0;y<H;y++){img.set(0,y,rc[0],rc[1],rc[2]);img.set(1,y,rc[0],rc[1],rc[2]);
                          img.set(W-1,y,rc[0],rc[1],rc[2]);img.set(W-2,y,rc[0],rc[1],rc[2]);}
    if(cd.rarIdx>=3){
        for(int x=2;x<W-2;x++){img.set(x,2,rc[0],rc[1],rc[2]);img.set(x,H-3,rc[0],rc[1],rc[2]);}
        for(int y=2;y<H-2;y++){img.set(2,y,rc[0],rc[1],rc[2]);img.set(W-3,y,rc[0],rc[1],rc[2]);}
    }

    // ── 18. Indicateur de type ────────────────────────────────────────────────
    static const uint8_t typCol[6][3]={
        {80,160,200},{100,200,100},{180,80,200},{200,80,80},{80,120,220},{220,180,60}};
    static const char* typSym[6]={"S","I","M","A","D","U"};
    auto* tc=typCol[cd.typeIdx];
    img.circle(W-14,H-14,9,tc[0],tc[1],tc[2]);
    img.circle(W-14,H-14,7,drk(tc[0],20),drk(tc[1],20),drk(tc[2],20));
    // Lettre
    const char* sym=typSym[cd.typeIdx];
    if(sym[0]=='A'){
        img.line(W-18,H-8,W-14,H-18,245,245,255,2);
        img.line(W-14,H-18,W-10,H-8,245,245,255,2);
        img.line(W-17,H-12,W-11,H-12,245,245,255,1);
    }else{
        img.rect(W-17,H-18,6,10,245,245,255);
    }

    img.save(path);
}

// ─── Point d'entrée ───────────────────────────────────────────────────────────
int main(){
    initCRC();
    MKDIRP("assets");
    printf("Grand Line Legends — génération des assets (128×128)...\n");
    printf("Génération des %d portraits...\n", NB_CHARS);
    for(int i=0;i<NB_CHARS;i++) genChar(CHARS[i]);
    printf("Terminé — %d portraits PNG dans assets/\n", NB_CHARS);
    return 0;
}

"""
fetch_portraits.py — Télécharge les portraits One Piece depuis la wiki Fandom,
supprime le fond avec rembg et sauvegarde en PNG 128×128 dans assets/.

Usage : python tools/fetch_portraits.py
"""

import os, sys, time, requests
from io import BytesIO
from PIL import Image
import rembg

# ── Mapping nom jeu → nom article wiki One Piece ──────────────────────────────
WIKI_NAMES = {
    "Luffy":        "Monkey D. Luffy",
    "Zoro":         "Roronoa Zoro",
    "Sanji":        "Vinsmoke Sanji",
    "Brook":        "Brook",
    "Lucci":        "Rob Lucci",
    "Killer":       "Killer",
    "Usopp":        "Usopp",
    "Franky":       "Franky",
    "Vivi":         "Nefertari Vivi",
    "Nami":         "Nami",
    "Koby":         "Koby",
    "BonClay":      "Bentham",
    "Baggy":        "Buggy",
    "Bepo":         "Bepo",
    "Chopper":      "Tony Tony Chopper",
    "Bege":         "Capone Bege",
    "Berouge":      "Bellmere",       # Belle-mère de Nami (marine avec béret)
    "Momonosuke":   "Kozuki Momonosuke",
    "Burgess":      "Jesus Burgess",
    "Carrot":       "Carrot",
    "VanAugur":     "Van Augur",
    "Bonney":       "Jewelry Bonney",
    "Appo":         "Scratchmen Apoo",
    "Ivankov":      "Emporio Ivankov",
    "XDrake":       "X Drake",
    "GeckoMoria":   "Gecko Moria",
    "Izo":          "Izou",
    "Smoker":       "Smoker",
    "Jinbe":        "Jinbe",
    "Robin":        "Nico Robin",
    "Crocodile":    "Crocodile",
    "Kuma":         "Bartholomew Kuma",
    "Kid":          "Eustass Kid",
    "Yamato":       "Yamato",
    "BoaHancock":   "Boa Hancock",
    "Hawkins":      "Basil Hawkins",
    "Ace":          "Portgas D. Ace",
    "Shiliew":      "Shiryu",
    "Yasopp":       "Yasopp",
    "Doflamingo":   "Donquixote Doflamingo",
    "Vegapunk":     "Vegapunk",
    "DoggyBroggy":  "Dorry",           # Dorry et Brogy → prend Dorry
    "Zunesha":      "Zunesha",
    "Emeth":        "Oimo",            # géant de la wiki
    "Fujitora":     "Fujitora",
    "King":         "King",
    "Katakuri":     "Charlotte Katakuri",
    "BenBeckman":   "Benn Beckman",
    "Ener":         "Enel",
    "Ryokugyu":     "Ryokugyu",
    "Marco":        "Marco",
    "Rayleigh":     "Silvers Rayleigh",
    "Law":          "Trafalgar D. Water Law",
    "Sengoku":      "Sengoku",
    "Akainu":       "Sakazuki",
    "Kizaru":       "Borsalino",
    "Aokiji":       "Kuzan",
    "Sabo":         "Sabo",
    "Crocus":       "Crocus",
    "Shanks":       "Shanks",
    "Garp":         "Monkey D. Garp",
    "Dragon":       "Monkey D. Dragon",
    "Mihawk":       "Dracule Mihawk",
    "Kaido":        "Kaidou",
    "BigMom":       "Charlotte Linlin",
    "BarbeNoire":   "Marshall D. Teach",
    "BarbeBlanche": "Edward Newgate",
}

# URLs directes connues (fiables, évitent l'API)
DIRECT_URLS = {
    "Luffy":        "https://static.wikia.nocookie.net/onepiece/images/6/6d/Monkey_D._Luffy_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Zoro":         "https://static.wikia.nocookie.net/onepiece/images/5/52/Roronoa_Zoro_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Nami":         "https://static.wikia.nocookie.net/onepiece/images/6/68/Nami_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Sanji":        "https://static.wikia.nocookie.net/onepiece/images/b/b6/Sanji_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Usopp":        "https://static.wikia.nocookie.net/onepiece/images/3/35/Usopp_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Chopper":      "https://static.wikia.nocookie.net/onepiece/images/a/af/Tony_Tony_Chopper_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Robin":        "https://static.wikia.nocookie.net/onepiece/images/b/bc/Nico_Robin_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Franky":       "https://static.wikia.nocookie.net/onepiece/images/8/8c/Franky_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Brook":        "https://static.wikia.nocookie.net/onepiece/images/4/41/Brook_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Jinbe":        "https://static.wikia.nocookie.net/onepiece/images/8/81/Jinbe_Anime_Infobox.png/revision/latest",
    "Shanks":       "https://static.wikia.nocookie.net/onepiece/images/6/66/Shanks_Anime_Infobox.png/revision/latest",
    "Ace":          "https://static.wikia.nocookie.net/onepiece/images/4/4f/Portgas_D._Ace_Anime_Infobox.png/revision/latest",
    "BarbeBlanche": "https://static.wikia.nocookie.net/onepiece/images/b/b7/Edward_Newgate_Anime_Infobox.png/revision/latest",
    "BarbeNoire":   "https://static.wikia.nocookie.net/onepiece/images/f/ff/Marshall_D._Teach_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Law":          "https://static.wikia.nocookie.net/onepiece/images/4/4d/Trafalgar_D._Water_Law_Anime_Post_Timeskip_Infobox.png/revision/latest",
    "Doflamingo":   "https://static.wikia.nocookie.net/onepiece/images/7/7e/Donquixote_Doflamingo_Anime_Infobox.png/revision/latest",
    "Kaido":        "https://static.wikia.nocookie.net/onepiece/images/2/2d/Kaidou_Anime_Infobox.png/revision/latest",
    "BigMom":       "https://static.wikia.nocookie.net/onepiece/images/d/d8/Charlotte_Linlin_Anime_Infobox.png/revision/latest",
    "Mihawk":       "https://static.wikia.nocookie.net/onepiece/images/b/bf/Dracule_Mihawk_Anime_Infobox.png/revision/latest",
    "Dragon":       "https://static.wikia.nocookie.net/onepiece/images/f/f5/Monkey_D._Dragon_Anime_Infobox.png/revision/latest",
}

HEADERS = {"User-Agent": "Mozilla/5.0 (compatible; GrandLineLegends/1.0)"}
API_BASE = "https://onepiece.fandom.com/api.php"
OUTPUT_SIZE = (128, 128)
OUTPUT_DIR  = "assets"

# ── Fonctions utilitaires ─────────────────────────────────────────────────────

def get_image_url_via_api(wiki_title: str) -> str | None:
    """Interroge l'API MediaWiki pour obtenir l'URL de l'image principale."""
    # Étape 1 : récupérer le nom du fichier image principal
    r = requests.get(API_BASE, params={
        "action": "query",
        "titles": wiki_title,
        "prop":   "pageimages",
        "piprop": "name",
        "format": "json",
        "pilimit": 1,
    }, headers=HEADERS, timeout=15)
    if r.status_code != 200:
        return None
    data = r.json()
    pages = data.get("query", {}).get("pages", {})
    filename = None
    for page in pages.values():
        filename = page.get("pageimage")
        break
    if not filename:
        return None

    # Étape 2 : récupérer l'URL CDN du fichier
    r2 = requests.get(API_BASE, params={
        "action":  "query",
        "titles":  f"File:{filename}",
        "prop":    "imageinfo",
        "iiprop":  "url",
        "format":  "json",
    }, headers=HEADERS, timeout=15)
    if r2.status_code != 200:
        return None
    data2 = r2.json()
    pages2 = data2.get("query", {}).get("pages", {})
    for page in pages2.values():
        info = page.get("imageinfo", [])
        if info:
            return info[0].get("url")
    return None


def download_image(url: str) -> Image.Image | None:
    """Télécharge une image et retourne un objet PIL."""
    try:
        r = requests.get(url, headers=HEADERS, timeout=20)
        if r.status_code == 200:
            return Image.open(BytesIO(r.content)).convert("RGBA")
    except Exception as e:
        print(f"    Erreur téléchargement : {e}")
    return None


def remove_background(img: Image.Image) -> Image.Image:
    """Supprime le fond avec rembg (IA) si l'image n'est pas déjà transparente."""
    # Si l'image a déjà un canal alpha significatif, pas besoin de rembg
    if img.mode == "RGBA":
        alpha = img.getchannel("A")
        non_opaque = sum(1 for px in alpha.getdata() if px < 250)
        total = alpha.width * alpha.height
        if non_opaque > total * 0.05:   # >5% de pixels transparents → déjà ok
            return img
    # Supprimer le fond
    buf_in  = BytesIO()
    img.save(buf_in, format="PNG")
    buf_out = rembg.remove(buf_in.getvalue())
    return Image.open(BytesIO(buf_out)).convert("RGBA")


def crop_to_face(img: Image.Image) -> Image.Image:
    """
    Cadre l'image sur la partie non-transparente,
    puis recentre dans un carré OUTPUT_SIZE avec fond transparent.
    """
    bbox = img.getbbox()
    if not bbox:
        return img.resize(OUTPUT_SIZE, Image.LANCZOS)
    cropped = img.crop(bbox)

    # Créer un fond transparent carré et coller l'image centrée
    result = Image.new("RGBA", OUTPUT_SIZE, (0, 0, 0, 0))
    cropped.thumbnail((OUTPUT_SIZE[0], OUTPUT_SIZE[1]), Image.LANCZOS)
    x = (OUTPUT_SIZE[0] - cropped.width)  // 2
    y = (OUTPUT_SIZE[1] - cropped.height) // 2
    result.paste(cropped, (x, y), cropped)
    return result


# ── Boucle principale ─────────────────────────────────────────────────────────

def process_character(name: str) -> bool:
    out_path = os.path.join(OUTPUT_DIR, f"char_{name}.png")

    # URL directe connue ?
    url = DIRECT_URLS.get(name)

    if not url:
        wiki_title = WIKI_NAMES.get(name)
        if not wiki_title:
            print(f"  [{name}] Pas de mapping wiki → skip")
            return False
        print(f"  [{name}] Recherche API pour « {wiki_title} »…")
        url = get_image_url_via_api(wiki_title)
        if not url:
            print(f"  [{name}] Introuvable via API → skip")
            return False

    print(f"  [{name}] Téléchargement…")
    img = download_image(url)
    if img is None:
        print(f"  [{name}] Échec téléchargement")
        return False

    print(f"  [{name}] Suppression du fond…")
    img = remove_background(img)

    print(f"  [{name}] Recadrage et sauvegarde…")
    img = crop_to_face(img)
    img.save(out_path, "PNG")
    print(f"  [{name}] ✓  →  {out_path}")
    return True


def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    all_names = list(WIKI_NAMES.keys())
    total = len(all_names)
    ok = 0

    print(f"=== Grand Line Legends — fetch_portraits ({total} personnages) ===\n")
    print("(Première exécution : rembg télécharge son modèle IA ~170 Mo)\n")

    for i, name in enumerate(all_names, 1):
        print(f"[{i}/{total}]", end=" ")
        try:
            if process_character(name):
                ok += 1
        except Exception as e:
            print(f"  [{name}] ERREUR : {e}")
        time.sleep(0.3)   # Respecter le rate-limit Fandom

    print(f"\n=== Terminé : {ok}/{total} portraits générés dans {OUTPUT_DIR}/ ===")
    if ok < total:
        print(f"    {total - ok} personnages sans image → sprites procéduraux utilisés")


if __name__ == "__main__":
    main()

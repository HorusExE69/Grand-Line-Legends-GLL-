"""
fix2_portraits.py — Recadrage corrigé pour les 18 personnages mal cadrés.
Stratégies :
  - 80% hauteur  : personnages avec bras coupés
  - 95% hauteur  : personnages avec buste/corps manquant
  - 100% hauteur : personnages avec composition bizarre
  - Manga infobox : fallback si l'image anime est bizarre
"""
import os, time, requests
from io import BytesIO
from PIL import Image
from rembg import remove, new_session

HEADERS  = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"}
API_BASE = "https://onepiece.fandom.com/api.php"
OUT_DIR  = "assets"
SIZE     = (128, 128)

# (wiki_title, crop_ratio, fallback_file)
# crop_ratio : fraction du HAUT du personnage à garder
FIX = {
    "Akainu":       ("Sakazuki",                0.82, "Sakazuki_Manga_Infobox.png"),
    "Appo":         ("Scratchmen Apoo",         0.82, "Scratchmen_Apoo_Anime_Infobox.png"),
    "BarbeBlanche": ("Edward Newgate",          0.82, "Edward_Newgate_Manga_Infobox.png"),
    "BigMom":       ("Charlotte Linlin",        1.00, "Charlotte_Linlin_Manga_Infobox.png"),
    "BonClay":      ("Bentham",                 1.00, "Bentham_Anime_Infobox.png"),
    "GeckoMoria":   ("Gecko Moria",             0.90, "Gecko_Moria_Manga_Infobox.png"),
    "Hawkins":      ("Basil Hawkins",           1.00, "Basil_Hawkins_Manga_Infobox.png"),
    "Ivankov":      ("Emporio Ivankov",         0.95, "Emporio_Ivankov_Manga_Infobox.png"),
    "Katakuri":     ("Charlotte Katakuri",      1.00, "Charlotte_Katakuri_Manga_Infobox.png"),
    "Kid":          ("Eustass Kid",             0.82, "Eustass_Kid_Manga_Infobox.png"),
    "Killer":       ("Killer",                  0.85, "Killer_Manga_Infobox.png"),
    "King":         ("King",                    1.00, "King_Manga_Infobox.png"),
    "Kuma":         ("Bartholomew Kuma",        0.82, "Bartholomew_Kuma_Manga_Infobox.png"),
    "Lucci":        ("Rob Lucci",               1.00, "Rob_Lucci_Manga_Infobox.png"),
    "Sengoku":      ("Sengoku",                 0.82, "Sengoku_Manga_Infobox.png"),
    "Usopp":        ("Usopp",                   0.70, "Usopp_Manga_Infobox.png"),
    "VanAugur":     ("Van Augur",               1.00, "Van_Augur_Manga_Infobox.png"),
    "XDrake":       ("X Drake",                 0.82, "X_Drake_Manga_Infobox.png"),
}

print("Chargement modele isnet-anime...")
session = new_session("isnet-anime")
print("Pret.\n")


def get_url_api(wiki_title: str) -> str | None:
    r = requests.get(API_BASE, params={
        "action": "query", "titles": wiki_title,
        "prop": "pageimages", "piprop": "name",
        "format": "json", "pilimit": 1,
    }, headers=HEADERS, timeout=15)
    if r.status_code != 200:
        return None
    pages = r.json().get("query", {}).get("pages", {})
    fn = None
    for p in pages.values():
        fn = p.get("pageimage"); break
    if not fn:
        return None
    r2 = requests.get(API_BASE, params={
        "action": "query", "titles": f"File:{fn}",
        "prop": "imageinfo", "iiprop": "url", "format": "json",
    }, headers=HEADERS, timeout=15)
    for p in r2.json().get("query", {}).get("pages", {}).values():
        info = p.get("imageinfo", [])
        if info:
            return info[0].get("url")
    return None


def get_url_file(filename: str) -> str | None:
    r = requests.get(API_BASE, params={
        "action": "query", "titles": f"File:{filename}",
        "prop": "imageinfo", "iiprop": "url", "format": "json",
    }, headers=HEADERS, timeout=15)
    for p in r.json().get("query", {}).get("pages", {}).values():
        info = p.get("imageinfo", [])
        if info:
            return info[0].get("url")
    return None


def smart_crop(img: Image.Image, ratio: float) -> Image.Image:
    """
    Prend le haut `ratio` du personnage détouré,
    en conservant toute la largeur du bounding box.
    Retourne un carré 128x128 avec fond transparent.
    """
    bbox = img.getbbox()
    if not bbox:
        return img.resize(SIZE, Image.LANCZOS)
    x0, y0, x1, y1 = bbox
    h = y1 - y0
    w = x1 - x0

    # Crop vertical
    crop_h = max(1, int(h * ratio))
    # Légèrement plus large que le bbox pour ne pas couper les bras
    pad_x = max(0, int(w * 0.04))
    x0c = max(0, x0 - pad_x)
    x1c = min(img.width, x1 + pad_x)
    cropped = img.crop((x0c, y0, x1c, y0 + crop_h))

    # Réduire pour tenir dans SIZE
    cropped.thumbnail(SIZE, Image.LANCZOS)

    # Centrer dans 128x128
    canvas = Image.new("RGBA", SIZE, (0, 0, 0, 0))
    ox = (SIZE[0] - cropped.width)  // 2
    oy = (SIZE[1] - cropped.height) // 2
    canvas.paste(cropped, (ox, oy), cropped)
    return canvas


def process(game_name: str, wiki_title: str, ratio: float, fallback: str) -> bool:
    print(f"[{game_name}] (crop={int(ratio*100)}%)")

    # 1. Essayer l'image anime principale
    url = get_url_api(wiki_title)
    src = "anime API"
    if not url:
        # 2. Fallback : manga infobox
        url = get_url_file(fallback)
        src = f"manga fallback ({fallback[:40]})"
    if not url:
        print(f"  Aucune URL trouvee")
        return False

    print(f"  Source : {src}")
    r = requests.get(url, headers=HEADERS, timeout=25)
    if r.status_code != 200:
        print(f"  HTTP {r.status_code}")
        return False

    img = Image.open(BytesIO(r.content)).convert("RGBA")
    print(f"  Taille source : {img.size}")

    # Détourage IA
    buf = BytesIO()
    img.save(buf, "PNG")
    result = Image.open(BytesIO(remove(buf.getvalue(), session=session))).convert("RGBA")

    # Vérif que le détourage n'a pas tout effacé
    vis_full = sum(1 for px in result.getchannel("A").getdata() if px > 30)
    if vis_full < 500:
        print(f"  Detourage trop agressif, utilisation image originale")
        result = img  # fallback : garder fond

    portrait = smart_crop(result, ratio)

    vis = sum(1 for px in portrait.getchannel("A").getdata() if px > 30)
    pct = vis * 100 // (SIZE[0] * SIZE[1])
    print(f"  Visible : {pct}%")

    out = os.path.join(OUT_DIR, f"char_{game_name}.png")
    portrait.save(out, "PNG")
    print(f"  OK -> {out}")
    return True


def main():
    ok = 0
    total = len(FIX)
    for i, (game_name, (wiki_title, ratio, fallback)) in enumerate(FIX.items(), 1):
        print(f"\n[{i}/{total}]", end=" ")
        try:
            if process(game_name, wiki_title, ratio, fallback):
                ok += 1
        except Exception as e:
            print(f"  ERREUR : {e}")
        time.sleep(0.4)

    print(f"\n\nTermine : {ok}/{total} portraits corriges.")

    # Verification finale
    print("\n--- Verification ---")
    bad = []
    for f in sorted(os.listdir(OUT_DIR)):
        if not f.startswith("char_") or not f.endswith(".png"):
            continue
        name = f[5:-4]
        img = Image.open(f"{OUT_DIR}/{f}").convert("RGBA")
        vis = sum(1 for px in img.getchannel("A").getdata() if px > 30)
        pct = vis * 100 // (SIZE[0] * SIZE[1])
        if pct < 10:
            bad.append(f"{name} ({pct}%)")
    if bad:
        print(f"Insuffisants : {bad}")
    else:
        print(f"Tous les portraits OK.")


if __name__ == "__main__":
    main()
